package com.maa.tracking_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
