import 'package:flutter/material.dart';

const String _imagesPath = "assets/images/";

const String _iconsPath = "${_imagesPath}icons/";

class Assets {
  static final shared = Assets();

  // TODO: - Colors

  final Color primaryColor = const Color(0xff0A2A6B);

  final Color secondaryColor = const Color(0xffD3E7EE);

  final Color emptyColor = const Color(0xffa09d9d);

  final Color scaffoldBackgroundColor = const Color(0xffffffff);

  // TODO: - Fonts

  final String primaryFont = 'NeoSansArabic';

  // TODO: - Icons

  final String icLogo = "${_iconsPath}logo.png";

  // TODO: - Images

  final String bgSplash = "${_imagesPath}bg_splash.png";

  final String icBell = "${_imagesPath}bell.png";
  final String icLogout = "${_imagesPath}close-circle.png";
  final String icHome = "${_imagesPath}home.png";
  final String icLoc = "${_imagesPath}loc.png";
  final String icNotification = "${_imagesPath}notification.png";
  final String icProfile = "${_imagesPath}profile-circle.png";
  final String imgProfile = "${_imagesPath}profile_img.png";
  final String imgStreet = "${_imagesPath}street.png";
  final String icUserPlus = "${_imagesPath}user-plus.png";
  final String icUserEdit = "${_imagesPath}user_edit.png";
  final String icNot = "${_imagesPath}ic_not.png";
  final String icCheck = "${_imagesPath}ic_check.png";
  final String icId = "${_imagesPath}id.png";
  final String icBus = "${_imagesPath}bus_prev.png";
  final String icWork = "${_imagesPath}work.png";
  final String icHelp = "${_imagesPath}ic_help.png";
  final String icSuccess = "${_imagesPath}success.png";
  final String icBlood = "${_imagesPath}blood.png";
  final String icBus2 = "${_imagesPath}bus2.png";
  final String icCalender = "${_imagesPath}calendar.png";
  final String icGender = "${_imagesPath}gender.png";
  final String icPassport = "${_imagesPath}passport.png";
}
