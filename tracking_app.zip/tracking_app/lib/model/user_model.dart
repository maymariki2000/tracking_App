import 'package:cloud_firestore/cloud_firestore.dart';

import '../services/firebase_constants.dart';

class UserModel {
  String uid;
  String email;
  String password;
  String? name;
  String? nationalId;
  String? campaignNo;
  String? companyId;
  String? latLng;

  UserModel({
    required this.uid,
    required this.email,
    required this.password,
    required this.name,
    this.nationalId,
    this.campaignNo,
    this.companyId,
    this.latLng,
  });

  Map<String, dynamic> toJson() => {
        FirebaseConstants.pathUserUuid: uid,
        FirebaseConstants.pathUserEmail: email,
        FirebaseConstants.pathName: name,
        FirebaseConstants.pathNationalId: nationalId,
        FirebaseConstants.pathCampaignNo: campaignNo,
        FirebaseConstants.pathCompanyId: companyId,
        FirebaseConstants.pathUserPassword: password,
        FirebaseConstants.pathLatLng: latLng
      };

  factory UserModel.fromJson(Map<String, dynamic> json) => UserModel(
        uid: json[FirebaseConstants.pathUserUuid],
        email: json[FirebaseConstants.pathUserEmail],
        name: json[FirebaseConstants.pathName],
        nationalId: json[FirebaseConstants.pathNationalId],
        campaignNo: json[FirebaseConstants.pathCampaignNo],
        companyId: json[FirebaseConstants.pathCompanyId],
        password: json[FirebaseConstants.pathUserPassword],
        latLng: json[FirebaseConstants.pathLatLng],
      );

  factory UserModel.fromDocument(DocumentSnapshot doc) {
    String uid = "";
    String email = "";
    String name = "";
    String password = "";
    String nationalId = "";
    String campaignNo = "";
    String companyId = "";
    String latLng = "";

    try {
      uid = doc.id;
    } catch (e) {}

    try {
      email = doc.get(FirebaseConstants.pathUserEmail);
    } catch (e) {}

    try {
      name = doc.get(FirebaseConstants.pathName);
    } catch (e) {}

    try {
      nationalId = doc.get(FirebaseConstants.pathNationalId);
    } catch (e) {}

    try {
      password = doc.get(FirebaseConstants.pathUserPassword);
    } catch (e) {}

    try {
      companyId = doc.get(FirebaseConstants.pathCompanyId);
    } catch (e) {}
    try {
      campaignNo = doc.get(FirebaseConstants.pathCampaignNo);
    } catch (e) {}

    try {
      latLng = doc.get(FirebaseConstants.pathLatLng);
    } catch (e) {}

    return UserModel(
      uid: uid,
      email: email,
      name: name,
      password: password,
      nationalId: nationalId,
      companyId: companyId,
      campaignNo: campaignNo,
      latLng: latLng,
    );
  }
}
