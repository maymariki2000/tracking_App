import 'package:cloud_firestore/cloud_firestore.dart';

import '../services/firebase_constants.dart';

class HelpModel {
  String uid;
  String title;
  String senderId;
  String receiverId;

  HelpModel({
    required this.uid,
    required this.title,
    required this.senderId,
    required this.receiverId,
  });

  Map<String, dynamic> toJson() => {
        FirebaseConstants.pathUid: uid,
        FirebaseConstants.pathTitle: title,
        FirebaseConstants.pathSenderId: senderId,
        FirebaseConstants.receiverId: receiverId,
      };

  factory HelpModel.fromJson(Map<String, dynamic> json) => HelpModel(
        uid: json[FirebaseConstants.pathUid],
        title: json[FirebaseConstants.pathTitle],
        senderId: json[FirebaseConstants.pathSenderId],
        receiverId: json[FirebaseConstants.receiverId],
      );

  factory HelpModel.fromDocument(DocumentSnapshot doc) {
    String uid = "";
    String title = "";
    String senderId = "";
    String receiverId = "";

    try {
      uid = doc.id;
    } catch (e) {}

    try {
      title = doc.get(FirebaseConstants.pathTitle);
    } catch (e) {}

    try {
      senderId = doc.get(FirebaseConstants.pathSenderId);
    } catch (e) {}

    try {
      receiverId = doc.get(FirebaseConstants.receiverId);
    } catch (e) {}

    return HelpModel(
      uid: uid,
      title: title,
      senderId: senderId,
      receiverId: receiverId,
    );
  }
}
