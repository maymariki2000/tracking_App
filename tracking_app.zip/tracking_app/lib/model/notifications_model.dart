import 'package:cloud_firestore/cloud_firestore.dart';

import '../services/firebase_constants.dart';

class NotificationModel {
  String? uid;
  String title;
  String senderId;
  String receiverId;
  String? isChecked;

  NotificationModel({
    this.uid,
    required this.title,
    required this.senderId,
    required this.receiverId,
    this.isChecked,
  });

  Map<String, dynamic> toJson() => {
        FirebaseConstants.pathUid: uid,
        FirebaseConstants.pathTitle: title,
        FirebaseConstants.pathSenderId: senderId,
        FirebaseConstants.receiverId: receiverId,
        FirebaseConstants.pathIsChecked: isChecked,
      };

  factory NotificationModel.fromJson(Map<String, dynamic> json) =>
      NotificationModel(
        uid: json[FirebaseConstants.pathUid],
        title: json[FirebaseConstants.pathTitle],
        senderId: json[FirebaseConstants.pathSenderId],
        receiverId: json[FirebaseConstants.receiverId],
        isChecked: json[FirebaseConstants.pathIsChecked],
      );

  factory NotificationModel.fromDocument(DocumentSnapshot doc) {
    String uid = "";
    String title = "";
    String senderId = "";
    String receiverId = "";
    String isChecked = "";

    try {
      uid = doc.id;
    } catch (e) {}

    try {
      title = doc.get(FirebaseConstants.pathTitle);
    } catch (e) {}

    try {
      senderId = doc.get(FirebaseConstants.pathSenderId);
    } catch (e) {}

    try {
      receiverId = doc.get(FirebaseConstants.receiverId);
    } catch (e) {}

    try {
      isChecked = doc.get(FirebaseConstants.pathIsChecked);
    } catch (e) {}

    return NotificationModel(
      uid: uid,
      title: title,
      senderId: senderId,
      receiverId: receiverId,
      isChecked: isChecked,
    );
  }
}
