import 'package:cloud_firestore/cloud_firestore.dart';

import '../services/firebase_constants.dart';

class CompanyModel {
  String uid;
  String title;

  CompanyModel({
    required this.uid,
    required this.title,
  });

  Map<String, dynamic> toJson() => {
        FirebaseConstants.pathUid: uid,
        FirebaseConstants.pathTitle: title,
      };

  factory CompanyModel.fromJson(Map<String, dynamic> json) => CompanyModel(
        uid: json[FirebaseConstants.pathUid],
        title: json[FirebaseConstants.pathTitle],
      );

  factory CompanyModel.fromDocument(DocumentSnapshot doc) {
    String uid = "";
    String title = "";

    try {
      uid = doc.id;
    } catch (e) {}

    try {
      title = doc.get(FirebaseConstants.pathTitle);
    } catch (e) {}

    return CompanyModel(
      uid: uid,
      title: title,
    );
  }
}
