import 'package:cloud_firestore/cloud_firestore.dart';

import '../services/firebase_constants.dart';

class HajModel {
  String? uid;
  String? name;
  String? passport;
  String? password;
  String? birthdate;
  String? gender;
  String? campaignNo;
  String? busNo;
  String? nationality;
  String? bloodType;
  String? insertUid;
  String? latLng;

  HajModel({
    this.uid,
    this.name,
    this.passport,
    this.password,
    this.birthdate,
    this.gender,
    this.campaignNo,
    this.busNo,
    this.nationality,
    this.bloodType,
    this.insertUid,
    this.latLng,
  });

  Map<String, dynamic> toJson() => {
        FirebaseConstants.pathUid: uid,
        FirebaseConstants.pathName: name,
        FirebaseConstants.pathPassport: passport,
        FirebaseConstants.pathUserPassword: password,
        FirebaseConstants.pathBirthdate: birthdate,
        FirebaseConstants.pathGender: gender,
        FirebaseConstants.pathCampaignNo: campaignNo,
        FirebaseConstants.pathBusNo: busNo,
        FirebaseConstants.pathNationality: nationality,
        FirebaseConstants.pathBloodType: bloodType,
        FirebaseConstants.pathInsertUId: insertUid,
        FirebaseConstants.pathLatLng: latLng,
      };

  factory HajModel.fromJson(Map<String, dynamic> json) => HajModel(
        uid: json[FirebaseConstants.pathUid],
        name: json[FirebaseConstants.pathName],
        passport: json[FirebaseConstants.pathPassport],
        password: json[FirebaseConstants.pathUserPassword],
        birthdate: json[FirebaseConstants.pathBirthdate],
        gender: json[FirebaseConstants.pathGender],
        campaignNo: json[FirebaseConstants.pathCampaignNo],
        busNo: json[FirebaseConstants.pathBusNo],
        nationality: json[FirebaseConstants.pathNationality],
        bloodType: json[FirebaseConstants.pathBloodType],
        insertUid: json[FirebaseConstants.pathInsertUId],
        latLng: json[FirebaseConstants.pathLatLng],
      );

  factory HajModel.fromDocument(DocumentSnapshot doc) {
    String uid = "";
    String name = "";
    String passport = "";
    String password = "";
    String birthdate = "";
    String gender = "";
    String campaignNo = "";
    String busNo = "";
    String nationality = "";
    String bloodType = "";
    String insertUid = "";
    String latLng = "";

    try {
      uid = doc.id;
    } catch (e) {}

    try {
      name = doc.get(FirebaseConstants.pathName);
    } catch (e) {}
    try {
      passport = doc.get(FirebaseConstants.pathPassport);
    } catch (e) {}
    try {
      password = doc.get(FirebaseConstants.pathUserPassword);
    } catch (e) {}
    try {
      birthdate = doc.get(FirebaseConstants.pathBirthdate);
    } catch (e) {}
    try {
      gender = doc.get(FirebaseConstants.pathGender);
    } catch (e) {}
    try {
      campaignNo = doc.get(FirebaseConstants.pathCampaignNo);
    } catch (e) {}
    try {
      busNo = doc.get(FirebaseConstants.pathBusNo);
    } catch (e) {}
    try {
      nationality = doc.get(FirebaseConstants.pathNationality);
    } catch (e) {}
    try {
      bloodType = doc.get(FirebaseConstants.pathBloodType);
    } catch (e) {}

    try {
      insertUid = doc.get(FirebaseConstants.pathInsertUId);
    } catch (e) {}

    try {
      latLng = doc.get(FirebaseConstants.pathLatLng);
    } catch (e) {}

    return HajModel(
      uid: uid,
      name: name,
      passport: passport,
      password: password,
      birthdate: birthdate,
      gender: gender,
      campaignNo: campaignNo,
      busNo: busNo,
      nationality: nationality,
      bloodType: bloodType,
      insertUid: insertUid,
      latLng: latLng,
    );
  }
}
