import 'dart:io';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter_svprogresshud/flutter_svprogresshud.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get_storage/get_storage.dart';
import 'package:tracking_app/model/haj_model.dart';
import 'package:tracking_app/model/notifications_model.dart';

import '../model/company_model.dart';
import '../model/status_response.dart';
import '../model/user_model.dart';
import 'firebase_constants.dart';

FirebaseAuth auth = FirebaseAuth.instance;
FirebaseFirestore db = FirebaseFirestore.instance;

Future<StatusResponse> createFireUser(
  String name,
  String email,
  String nationalId,
  String password,
  String companyId,
  String campaignNo,
) async {
  SVProgressHUD.show();

  try {
    UserCredential result = (await auth.createUserWithEmailAndPassword(
      email: email,
      password: password,
    ));
    User? user = result.user;
    if (user != null) {
      db.collection(FirebaseConstants.pathUserCollection).doc(user.uid).set({
        FirebaseConstants.pathUserEmail: email,
        FirebaseConstants.pathUserPassword: password,
        FirebaseConstants.pathName: name,
        FirebaseConstants.pathNationalId: nationalId,
        FirebaseConstants.pathCompanyId: companyId,
        FirebaseConstants.pathCampaignNo: campaignNo,
      }).then((value) {
        print("saved user to Firestore");

        UserModel us = UserModel(
            uid: user.uid,
            email: email,
            name: name,
            password: password,
            companyId: companyId,
            campaignNo: campaignNo,
            nationalId: nationalId);
        saveUserToLocal(us);
      });
      SVProgressHUD.dismiss();
      return StatusResponse(message: "تم التسجيل بنجاح", status: true);
    } else {
      SVProgressHUD.dismiss();
      return StatusResponse(
          message: "حدث خطأ، يرجى المحاولة لاحقاً", status: false);
    }
  } on FirebaseException catch (e, w) {
    print(e.code);
    SVProgressHUD.dismiss();

    if (e.code == "email-already-in-use") {
      return StatusResponse(
          message: "البريد الالكتروني مستخدم من قبل", status: false);
    } else if (e.code == "weak-password") {
      return StatusResponse(
          message: "كلمة المرور يجب أن تكون ٦ أحرف على الأقل", status: false);
    } else {
      return StatusResponse(
          message: "حدث خطأ، يرجى المحاولة لاحقاً", status: false);
    }
  }
}

Future<StatusResponse> signInFireUser(String email, String password) async {
  SVProgressHUD.show();

  try {
    User? user = (await auth.signInWithEmailAndPassword(
      email: email,
      password: password,
    ))
        .user;
    SVProgressHUD.dismiss();

    return StatusResponse(message: "", status: true);
  } on FirebaseException catch (e, w) {
    SVProgressHUD.dismiss();

    print(e.code);
    if (e.code == "user-not-found") {
      return StatusResponse(
          message: "الايميل غير مسجل، يرجى التسجيل في التطبيق", status: false);
    } else if (e.code == "wrong-password") {
      return StatusResponse(message: "كلمة المرور خاطئة", status: false);
    } else {
      return StatusResponse(
          message: "حدث خطأ، يرجى المحاولة لاحقاً", status: false);
    }
  }
}

Future<UserModel?> getCurrentUser(String uid) async {
  SVProgressHUD.show();

  final DocumentSnapshot result =
      await db.collection(FirebaseConstants.pathUserCollection).doc(uid).get();
  print(result.data());
  SVProgressHUD.dismiss();

  if (result.exists) {
    UserModel userObj = UserModel.fromDocument(result);
    print("user exists");
    return userObj;
  } else {
    return null;
  }
}

String? getLocalUserUuid() {
  GetStorage box = GetStorage();
  var user = box.read(FirebaseConstants.userStoragePath);
  if (user != null) {
    return UserModel.fromJson(user).uid;
  } else {
    return null;
  }
}

UserModel? getLocalUser() {
  GetStorage box = GetStorage();
  var user = box.read(FirebaseConstants.userStoragePath);
  if (user != null) {
    return UserModel.fromJson(user);
  } else {
    return null;
  }
}

Future<UserModel?> getUserByUid(String uid) async {
  final DocumentSnapshot result =
      await db.collection(FirebaseConstants.pathUserCollection).doc(uid).get();

  if (result.exists) {
    UserModel user = UserModel.fromDocument(result);
    return user;
  } else {
    return null;
  }
}

Future<CompanyModel?> getCompanyByUid(String uid) async {
  final DocumentSnapshot result = await db
      .collection(FirebaseConstants.pathCompaniesCollection)
      .doc(uid)
      .get();

  if (result.exists) {
    CompanyModel craft = CompanyModel.fromDocument(result);
    return craft;
  } else {
    return null;
  }
}

// Future<List<UserModel>> getHerfiesFromFire() async {
//   final QuerySnapshot result =
//       await db.collection(FirebaseConstants.pathUserCollection).get();
//   final List<DocumentSnapshot> documents = result.docs;
//
//   List<UserModel> myListString = []; // My list I want to create.
//
//   documents.forEach((snapshot) {
//     UserModel user = UserModel.fromDocument(snapshot);
//     if (user.isHerfy == "1") {
//       myListString.add(user);
//     }
//   });
//
//   return myListString;
// }

Future<List<CompanyModel>> getCompanies() async {
  final QuerySnapshot result =
      await db.collection(FirebaseConstants.pathCompaniesCollection).get();
  final List<DocumentSnapshot> documents = result.docs;
  print(documents);

  List<CompanyModel> myListString = [];

  for (var snapshot in documents) {
    CompanyModel company = CompanyModel.fromDocument(snapshot);
    myListString.add(company);
  }

  return myListString;
}

Future<List<CompanyModel>> getNationalities() async {
  final QuerySnapshot result =
      await db.collection(FirebaseConstants.pathNationalitiesCollection).get();
  final List<DocumentSnapshot> documents = result.docs;
  print(documents);

  List<CompanyModel> myListString = [];

  for (var snapshot in documents) {
    CompanyModel company = CompanyModel.fromDocument(snapshot);
    myListString.add(company);
  }

  return myListString;
}

Future<List<NotificationModel>> getNotifications(String uid) async {
  final QuerySnapshot result = await db
      .collection(FirebaseConstants.pathNotificationsCollection)
      .where(FirebaseConstants.receiverId, isEqualTo: uid)
      .get();
  final List<DocumentSnapshot> documents = result.docs;

  List<NotificationModel> myListString = [];

  for (var snapshot in documents) {
    NotificationModel notification = NotificationModel.fromDocument(snapshot);
    myListString.add(notification);
  }

  return myListString;
}

Future<List<HajModel>> getHajs(String uid) async {
  final QuerySnapshot result = await db
      .collection(FirebaseConstants.pathHajCollection)
      .where(FirebaseConstants.pathInsertUId, isEqualTo: uid)
      .get();
  final List<DocumentSnapshot> documents = result.docs;

  List<HajModel> myListString = [];

  for (var snapshot in documents) {
    HajModel haj = HajModel.fromDocument(snapshot);
    myListString.add(haj);
  }

  return myListString;
}

Future<void> saveNotificationToFire(NotificationModel notf) async {
  db.collection(FirebaseConstants.pathNotificationsCollection).doc().set({
    FirebaseConstants.pathTitle: notf.title,
    FirebaseConstants.receiverId: notf.receiverId,
    FirebaseConstants.pathSenderId: notf.senderId,
  }).then((value) {
    print("saved craft to Firestore");
  });
}

Future<void> saveHajToFire(HajModel haj) async {
  var user = getLocalUser();

  db.collection(FirebaseConstants.pathHajCollection).doc().set({
    FirebaseConstants.pathName: haj.name,
    FirebaseConstants.pathPassport: haj.passport,
    FirebaseConstants.pathUserPassword: haj.password,
    FirebaseConstants.pathBirthdate: haj.birthdate,
    FirebaseConstants.pathGender: haj.gender,
    FirebaseConstants.pathCampaignNo: haj.campaignNo,
    FirebaseConstants.pathBusNo: haj.busNo,
    FirebaseConstants.pathNationality: haj.nationality,
    FirebaseConstants.pathBloodType: haj.bloodType,
    FirebaseConstants.pathInsertUId: user?.uid ?? "",
  }).then((value) {
    print("saved craft to Firestore");
  });
}

Future<void> updateHajFire(HajModel haj) async {
  var user = getLocalUser();

  db.collection(FirebaseConstants.pathHajCollection).doc(haj.uid).update({
    FirebaseConstants.pathName: haj.name,
    FirebaseConstants.pathPassport: haj.passport,
    FirebaseConstants.pathUserPassword: haj.password,
    FirebaseConstants.pathBirthdate: haj.birthdate,
    FirebaseConstants.pathGender: haj.gender,
    FirebaseConstants.pathCampaignNo: haj.campaignNo,
    FirebaseConstants.pathBusNo: haj.busNo,
    FirebaseConstants.pathNationality: haj.nationality,
    FirebaseConstants.pathBloodType: haj.bloodType,
    FirebaseConstants.pathInsertUId: user?.uid ?? "",
  }).then((value) {
    print("saved craft to Firestore");
  });
}

Future<void> updateCheckNotification(String uid) async {
  db.collection(FirebaseConstants.pathNotificationsCollection).doc(uid).update({
    FirebaseConstants.pathIsChecked: "1",
  }).then((value) {
    print("saved craft to Firestore");
  });
}

Future<void> updateHajLocation(String hajId, String latLng) async {
  db.collection(FirebaseConstants.pathHajCollection).doc(hajId).update({
    FirebaseConstants.pathLatLng: latLng,
  }).then((value) {
    print("saved craft to Firestore");
  });
}

Future<void> updateUserLocation(String uid, String latLng) async {
  db.collection(FirebaseConstants.pathUserCollection).doc(uid).update({
    FirebaseConstants.pathLatLng: latLng,
  }).then((value) {
    print("saved craft to Firestore");
  });
}

Future<HajModel?> checkHajExists(String passport) async {
  final QuerySnapshot result = await db
      .collection(FirebaseConstants.pathHajCollection)
      .where(FirebaseConstants.pathPassport, isEqualTo: passport)
      .get();

  final List<DocumentSnapshot> documents = result.docs;

  if (documents.isNotEmpty) {
    if (documents.first.exists) {
      HajModel haj = HajModel.fromDocument(documents.first);

      return haj;
    } else {
      return null;
    }
  } else {
    return null;
  }
}

void saveUserToLocal(UserModel user) {
  GetStorage box = GetStorage();
  box.write(FirebaseConstants.userStoragePath, user.toJson());
}

void deleteUserFromLocal() {
  GetStorage box = GetStorage();
  box.remove(FirebaseConstants.userStoragePath);
}

void saveHajToLocal(HajModel user) {
  GetStorage box = GetStorage();
  box.write(FirebaseConstants.hajStoragePath, user.toJson());
}

void deleteHajFromLocal() {
  GetStorage box = GetStorage();
  box.remove(FirebaseConstants.hajStoragePath);
}

HajModel? getLocalHaj() {
  GetStorage box = GetStorage();
  var user = box.read(FirebaseConstants.hajStoragePath);
  if (user != null) {
    return HajModel.fromJson(user);
  } else {
    return null;
  }
}
