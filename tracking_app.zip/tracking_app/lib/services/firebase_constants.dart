class FirebaseConstants {
  // User constants
  static const pathUserCollection = "users";
  static const pathUserEmail = "u_email";
  static const pathUserUuid = "u_uuid";
  static const pathUserPassword = "u_password";
  static const pathUserId = "u_id";
  static const pathName = "u_name";
  static const pathGender = "u_gender";
  static const pathBirthdate = "u_birthdate";
  static const pathPassport = "u_passport";
  static const pathNationalId = "u_national_id";
  static const pathCampaignNo = "u_campaign_no";
  static const pathBusNo = "u_bus_no";
  static const pathNationality = "u_nationality";
  static const pathBloodType = "u_blood_type";
  static const pathCompanyId = "u_company_id";
  static const pathInsertUId = "insert_UID";
  static const pathLatLng = "lat_lng";

  static const pathNationalitiesCollection = "nationalities";
  static const pathHajCollection = "haj";
  static const pathCompaniesCollection = "companies";
  static const pathUid = "uid";
  static const pathTitle = "title";

  static const pathNotificationsCollection = "notifications";

  static const pathSenderId = "sender_id";
  static const receiverId = "receiver_id";
  static const pathIsChecked = "is_checked";

  // other constants
  static const userStoragePath = "userData";
  static const hajStoragePath = "hajData";
}
