import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:tracking_app/model/notifications_model.dart';
import 'package:tracking_app/model/user_model.dart';
import 'package:tracking_app/services/firebase_operations.dart';
import 'package:tracking_app/views/continue_add_user_data_screen.dart';

import '../custom_widgets/custom_app_bar.dart';
import '../custom_widgets/custom_text.dart';
import '../custom_widgets/custom_text_field.dart';
import '../custom_widgets/main_button.dart';
import '../utils/assets.dart';

class NotificationScreen extends StatefulWidget {
  NotificationScreen({Key? key}) : super(key: key);

  @override
  State<NotificationScreen> createState() => _NotificationScreenState();
}

class _NotificationScreenState extends State<NotificationScreen> {
  String email = "";

  String password = "";

  List<NotificationModel> notifications = [];

  void fetchNotifications() async {
    UserModel? user = getLocalUser();
    List<NotificationModel> notf = await getNotifications(user?.uid ?? "");
    setState(() {
      notifications = notf;
    });
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    fetchNotifications();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CustomAppBar(
        title: "تنبيهات",
      ),
      body: SizedBox(
        width: double.infinity,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Expanded(
              child: Container(
                decoration: BoxDecoration(
                  color: Assets.shared.primaryColor,
                  borderRadius: BorderRadius.circular(30),
                ),
                padding: EdgeInsets.symmetric(vertical: 20.h),
                margin: EdgeInsets.symmetric(horizontal: 14.w, vertical: 20.h),
                child: ListView.builder(
                  itemCount: notifications.length,
                  itemBuilder: (context, i) {
                    return InkWell(
                      onTap: () {
                        updateCheckNotification(notifications[i].uid ?? "");
                        fetchNotifications();
                      },
                      child: Container(
                        margin:
                            EdgeInsets.symmetric(vertical: 8, horizontal: 20),
                        padding: EdgeInsets.symmetric(horizontal: 12),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(30),
                        ),
                        height: 60,
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Image.asset(Assets.shared.icNot),
                            CustomText(
                              text: notifications[i].title,
                              fontSize: 16,
                              textColor: Assets.shared.primaryColor,
                            ),
                            (notifications[i].isChecked != null &&
                                    notifications[i].isChecked != "")
                                ? Image.asset(Assets.shared.icCheck)
                                : const SizedBox(),
                          ],
                        ),
                      ),
                    );
                  },
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
