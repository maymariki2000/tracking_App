import 'dart:async';

import 'package:custom_info_window/custom_info_window.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_polyline_points/flutter_polyline_points.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:tracking_app/custom_widgets/custom_app_bar.dart';
import 'package:tracking_app/custom_widgets/custom_text.dart';
import 'package:tracking_app/model/user_model.dart';
import 'package:tracking_app/utils/assets.dart';
import 'package:location/location.dart' as Loc;
import 'package:url_launcher/url_launcher.dart';
import 'package:url_launcher/url_launcher_string.dart';

import '../model/haj_model.dart';
import '../model/notifications_model.dart';
import '../services/firebase_operations.dart';

class HajMapScreen extends StatefulWidget {
  const HajMapScreen({Key? key}) : super(key: key);

  @override
  _HajMapScreenState createState() => _HajMapScreenState();
}

class _HajMapScreenState extends State<HajMapScreen> {
  final Completer<GoogleMapController> _controller =
      Completer<GoogleMapController>();

  CustomInfoWindowController _customInfoWindowController =
      CustomInfoWindowController();

  static const CameraPosition _kGooglePlex = CameraPosition(
    target: LatLng(21.422510, 39.826168),
    zoom: 12,
  );

  HajModel? haj;
  UserModel? _user;

  List<dynamic> markersList = [];
  Map<MarkerId, Marker> markers = {};

  Loc.Location location = Loc.Location();

  bool? _serviceEnabled;
  Loc.PermissionStatus? _permissionGranted;
  Loc.LocationData? _locationData;
  String currentPoint = "";
  String googleAPiKey = "AIzaSyC1xTzuJMYp8F4Vs9dxiJZg3iAJkaEwipM";
  Map<PolylineId, Polyline> polylines = {};

  String startPoint = "19.1113716-41.9206472";
  String endPoint = "19.1096611-41.9194976";

  List<NotificationModel> notifications = [];

  void fetchHaj() async {
    HajModel? h = getLocalHaj();
    setState(() {
      haj = h;
    });

    var us = await getUserByUid(haj?.insertUid ?? "");
    setState(() {
      _user = us;
    });
    print("_user?.latLng = ${_user?.latLng}");
    fetchNotifications(haj?.uid ?? "");
    getCurrentLocation();
  }

  void fetchNotifications(String uid) async {
    List<NotificationModel> notf = await getNotifications(uid);
    setState(() {
      notifications = notf;
    });
  }

  _addMarker(LatLng position, String id) {
    MarkerId markerId = MarkerId(id);
    Marker marker = Marker(
        markerId: markerId,
        position: position,
        onTap: () async {
          // List<Placemark> placemarks = await placemarkFromCoordinates(
          //     position.latitude, position.longitude);
          //
        });
    markers[markerId] = marker;
  }

  void getCurrentLocation() async {
    print("ffff");
    _serviceEnabled = await location.serviceEnabled();
    if (!(_serviceEnabled ?? false)) {
      _serviceEnabled = await location.requestService();
      if (!(_serviceEnabled ?? false)) {
        return;
      }
    }

    _permissionGranted = await location.hasPermission();

    if (_permissionGranted == Loc.PermissionStatus.denied) {
      _permissionGranted = await location.requestPermission();
      if (_permissionGranted != Loc.PermissionStatus.granted) {
        return;
      }
    }

    _locationData = await location.getLocation();

    location.onLocationChanged.listen((Loc.LocationData loc) {
      if (currentPoint == "") {
        currentPoint = "${loc.latitude}-${loc.longitude}";

        setSourceAndDestinationIcons();
      }

      // setState(() {});
    });
  }

  @override
  void dispose() {
    // TODO: implement dispose
    super.dispose();
  }

  void setSourceAndDestinationIcons() async {
    var vv = _user?.latLng?.split("-");
    var currentUser = currentPoint.split("-");

    if (vv != null) {
      print(vv[0]);
      _addMarker(
          LatLng(double.parse(vv[0]), double.parse(vv[1])), "${vv[0]}_origin");
    }

    if (currentUser != null) {
      _addMarker(
        LatLng(double.parse(currentUser[0]), double.parse(currentUser[1])),
        (currentUser[0]) + "_destination",
      );
    }

    List<LatLng> polylineCoordinates = [];

    polylineCoordinates.add(LatLng(double.parse(vv![0]), double.parse(vv[1])));
    polylineCoordinates.add(
        LatLng(double.parse(currentUser[0]), double.parse(currentUser[1])));

    _getPolyline(
        double.parse(vv[0]),
        double.parse(vv[1]),
        double.parse(currentUser[0]),
        double.parse(currentUser[1]),
        _user?.uid ?? "",
        polylineCoordinates);
  }

  _getPolyline(double originLat, double originLng, double desLat, double desLng,
      String uid, List<LatLng> polylineCoordinates) async {
    PolylinePoints polylinePoints = PolylinePoints();
    // PolylineResult result = await polylinePoints.getRouteBetweenCoordinates(googleAPiKey,
    //     _originLatitude, _originLongitude, _destLatitude, _destLongitude);

    PolylineResult result = await polylinePoints.getRouteBetweenCoordinates(
      googleAPiKey,
      PointLatLng(originLat, originLng),
      PointLatLng(desLat, desLng),
      travelMode: TravelMode.driving,
    );
    print("result.points = ${result.points}");
    if (result.points.isNotEmpty) {
      result.points.forEach((PointLatLng point) {
        print("dddddsds");
        polylineCoordinates.add(LatLng(point.latitude, point.longitude));
      });
    }

    _addPolyLine(uid, polylineCoordinates);
  }

  _addPolyLine(String uid, List<LatLng> polylineCoordinates) {
    PolylineId id = const PolylineId("poly");
    Polyline polyline = Polyline(
        polylineId: id, color: Colors.red, points: polylineCoordinates);
    polylines[id] = polyline;
    print("polyline = $polyline");
    if (this.mounted) {
      print("Mmounted");
//https://maps.googleapis.com/maps/api/directions/json?origin=Toronto&destination=Montreal&key=YOUR_API_KEY
      setState(() {
        // Your state change code goes here
      });
    }
    // setState(() {});
  }

  @override
  void initState() {
    super.initState();
    fetchHaj();
  }

  static void navigateTo(double lat, double lng) async {
    // var uri = Uri.parse("google.navigation:q=$lat,$lng&mode=d");
    String googleUrl =
        'https://www.google.com/maps/search/?api=1&query=$lat,$lng';

    if (await canLaunchUrlString(googleUrl)) {
      await launchUrlString(googleUrl);
    } else {
      throw 'Could not launch ${googleUrl}';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CustomAppBar(
        title: "تتبع الباص",
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () {
          var vv = _user?.latLng?.split("-");
          print(vv);
          navigateTo(double.parse(vv![0]), double.parse(vv[1]));
        },
        label: const Text('ذهاب للعنوان'),
        icon: const Icon(Icons.directions),
        backgroundColor: Assets.shared.primaryColor,
      ),
      body: Stack(
        children: [
          GoogleMap(
            mapType: MapType.normal,
            initialCameraPosition: _kGooglePlex,
            markers: Set<Marker>.of(markers.values),
            polylines: Set<Polyline>.of(polylines.values),
            onTap: (position) {
              // getLocationData(position);
            },
            onMapCreated: (GoogleMapController controller) {
              _controller.complete(controller);
              _customInfoWindowController.googleMapController = controller;
            },
          ),
          // notifications.length > 0
          //     ? InkWell(
          //         onTap: () {
          //           var vv = _user?.latLng?.split("-");
          //           print(vv);
          //           navigateTo(double.parse(vv![0]), double.parse(vv[1]));
          //         },
          //         child: Column(
          //           crossAxisAlignment: CrossAxisAlignment.stretch,
          //           children: [
          //             const SizedBox(
          //               height: 25,
          //             ),
          //             Container(
          //               padding: EdgeInsets.symmetric(horizontal: 10.w),
          //               margin: EdgeInsets.symmetric(horizontal: 20.r),
          //               height: 60.h,
          //               decoration: BoxDecoration(
          //                   color: Assets.shared.primaryColor,
          //                   borderRadius: BorderRadius.circular(15),
          //                   boxShadow: [
          //                     BoxShadow(
          //                       color: Colors.black.withOpacity(0.16),
          //                       offset: Offset(0, 3),
          //                       blurRadius: 6,
          //                     ),
          //                   ]),
          //               child: Row(
          //                 children: [
          //                   Image.asset(Assets.shared.icNotification),
          //                   const SizedBox(
          //                     width: 10,
          //                   ),
          //                   Column(
          //                     mainAxisAlignment: MainAxisAlignment.center,
          //                     crossAxisAlignment: CrossAxisAlignment.start,
          //                     children: [
          //                       const CustomText(
          //                         text: "تنبيهات",
          //                         textColor: Colors.white,
          //                       ),
          //                       const SizedBox(
          //                         height: 5,
          //                       ),
          //                       CustomText(
          //                         text: notifications.last.title,
          //                         fontSize: 14,
          //                         textColor: Colors.white,
          //                       ),
          //                     ],
          //                   )
          //                 ],
          //               ),
          //             ),
          //             const Expanded(
          //               child: SizedBox(),
          //             ),
          //           ],
          //         ),
          //       )
          //     : SizedBox(),
          // CustomInfoWindow(
          //   controller: _customInfoWindowController,
          //   height: 50,
          //   width: 250.w,
          //   offset: 50,
          // ),
        ],
      ),
    );
  }
}
