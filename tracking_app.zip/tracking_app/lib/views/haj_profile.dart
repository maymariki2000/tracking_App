import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:location/location.dart';
import 'package:tracking_app/custom_widgets/custom_text.dart';
import 'package:tracking_app/model/haj_model.dart';
import 'package:tracking_app/services/firebase_operations.dart';
import 'package:tracking_app/views/welcome_screen.dart';

import '../utils/assets.dart';

class HajProfileScreen extends StatefulWidget {
  const HajProfileScreen({Key? key}) : super(key: key);

  @override
  _HajProfileScreenState createState() => _HajProfileScreenState();
}

class _HajProfileScreenState extends State<HajProfileScreen> {
  HajModel? haj;

  Location location = Location();

  bool? _serviceEnabled;
  PermissionStatus? _permissionGranted;
  LocationData? _locationData;
  String currentPoint = "";

  Timer? timer;

  void fetchHaj() async {
    HajModel? h = getLocalHaj();
    setState(() {
      haj = h;
    });
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    fetchHaj();
    getCurrentLocation();
  }

  void getCurrentLocation() async {
    print("ffff");
    _serviceEnabled = await location.serviceEnabled();
    if (!(_serviceEnabled ?? false)) {
      _serviceEnabled = await location.requestService();
      if (!(_serviceEnabled ?? false)) {
        return;
      }
    }

    _permissionGranted = await location.hasPermission();

    if (_permissionGranted == PermissionStatus.denied) {
      _permissionGranted = await location.requestPermission();
      if (_permissionGranted != PermissionStatus.granted) {
        return;
      }
    }

    _locationData = await location.getLocation();
    print("lat is ${_locationData?.latitude}");

    // bool sts = await startBusJourney(_driver?.busId ?? "",
    //     "${_locationData?.latitude}-${_locationData?.longitude}");
    //
    // if (sts) {
    //   setState(() {
    //     timer = Timer.periodic(
    //         const Duration(seconds: 15), (Timer t) => addPoint());
    //   });
    // }

    location.onLocationChanged.listen((LocationData loc) {
      print(loc.latitude);
      print(loc.longitude);
      currentPoint = "${loc.latitude}-${loc.longitude}";
      print(currentPoint);
      // setState(() {});
    });

    timer =
        Timer.periodic(Duration(seconds: 15), (Timer t) => updateLocation());

    print(_locationData?.latitude);
  }

  void updateLocation() {
    updateHajLocation(haj?.uid ?? "", currentPoint);
  }

  @override
  void dispose() {
    timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Assets.shared.primaryColor,
      body: Column(
        children: [
          Container(
            height: 150,
            color: Assets.shared.primaryColor,
          ),
          Expanded(
            child: Stack(
              children: [
                Container(
                  width: double.infinity,
                  decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.only(
                          topLeft:
                              Radius.circular(ScreenUtil().screenWidth / 2),
                          topRight:
                              Radius.circular(ScreenUtil().screenWidth / 2))),
                  child: Container(
                    child: Column(
                      children: [
                        const SizedBox(
                          height: 120,
                        ),
                        CustomText(
                          text: haj?.name ?? "",
                          textColor: Colors.black,
                        ),
                        const SizedBox(
                          height: 50,
                        ),
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 60),
                          child: Row(
                            children: [
                              Image.asset(Assets.shared.icPassport),
                              const SizedBox(
                                width: 10,
                              ),
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  const CustomText(
                                    text: 'رقم جواز السفر',
                                    textColor: Colors.black,
                                    fontSize: 20,
                                  ),
                                  const SizedBox(
                                    height: 8,
                                  ),
                                  CustomText(
                                    text: haj?.passport ?? "",
                                    fontSize: 15,
                                    textColor: Colors.black,
                                  ),
                                ],
                              )
                            ],
                          ),
                        ),
                        const SizedBox(
                          height: 10,
                        ),
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 60),
                          child: Container(
                            height: 1,
                            color: Colors.black,
                          ),
                        ),
                        const SizedBox(
                          height: 15,
                        ),
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 60),
                          child: Row(
                            children: [
                              Image.asset(Assets.shared.icCalender),
                              const SizedBox(
                                width: 10,
                              ),
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  const CustomText(
                                    text: 'تاريخ الميلاد',
                                    textColor: Colors.black,
                                    fontSize: 20,
                                  ),
                                  const SizedBox(
                                    height: 8,
                                  ),
                                  CustomText(
                                    text: haj?.birthdate ?? "",
                                    fontSize: 15,
                                    textColor: Colors.black,
                                  ),
                                ],
                              )
                            ],
                          ),
                        ),
                        const SizedBox(
                          height: 10,
                        ),
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 60),
                          child: Container(
                            height: 1,
                            color: Colors.black,
                          ),
                        ),
                        const SizedBox(
                          height: 15,
                        ),
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 60),
                          child: Row(
                            children: [
                              Image.asset(Assets.shared.icBlood),
                              const SizedBox(
                                width: 10,
                              ),
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  const CustomText(
                                    text: 'فصيلة الدم',
                                    textColor: Colors.black,
                                    fontSize: 20,
                                  ),
                                  const SizedBox(
                                    height: 8,
                                  ),
                                  CustomText(
                                    text: haj?.bloodType ?? "",
                                    fontSize: 15,
                                    textColor: Colors.black,
                                  ),
                                ],
                              )
                            ],
                          ),
                        ),
                        const SizedBox(
                          height: 10,
                        ),
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 60),
                          child: Container(
                            height: 1,
                            color: Colors.black,
                          ),
                        ),
                        const SizedBox(
                          height: 15,
                        ),
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 60),
                          child: Row(
                            children: [
                              Image.asset(Assets.shared.icBus2),
                              const SizedBox(
                                width: 10,
                              ),
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  const CustomText(
                                    text: 'رقم الحملة',
                                    textColor: Colors.black,
                                    fontSize: 20,
                                  ),
                                  const SizedBox(
                                    height: 8,
                                  ),
                                  CustomText(
                                    text: haj?.campaignNo ?? "",
                                    fontSize: 15,
                                    textColor: Colors.black,
                                  ),
                                ],
                              )
                            ],
                          ),
                        ),
                        const SizedBox(
                          height: 10,
                        ),
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 60),
                          child: Container(
                            height: 1,
                            color: Colors.black,
                          ),
                        ),
                        const SizedBox(
                          height: 15,
                        ),
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 60),
                          child: Row(
                            children: [
                              Image.asset(Assets.shared.icGender),
                              const SizedBox(
                                width: 10,
                              ),
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  const CustomText(
                                    text: 'الجنس',
                                    textColor: Colors.black,
                                    fontSize: 20,
                                  ),
                                  const SizedBox(
                                    height: 8,
                                  ),
                                  CustomText(
                                    text: haj?.gender ?? "",
                                    fontSize: 15,
                                    textColor: Colors.black,
                                  ),
                                ],
                              )
                            ],
                          ),
                        ),
                        const SizedBox(
                          height: 10,
                        ),
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 60),
                          child: Container(
                            height: 1,
                            color: Colors.black,
                          ),
                        ),
                        const SizedBox(
                          height: 15,
                        ),
                        InkWell(
                          onTap: () {
                            deleteHajFromLocal();
                            Get.offAll(
                              () => const WelcomeScreen(),
                            );
                          },
                          child: Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 60),
                            child: Row(
                              children: [
                                const Icon(
                                  Icons.exit_to_app,
                                  color: Colors.black,
                                  size: 30,
                                ),
                                const SizedBox(
                                  width: 10,
                                ),
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: const [
                                    CustomText(
                                      text: 'تسجيل الخروج',
                                      textColor: Colors.black,
                                      fontSize: 20,
                                    ),
                                  ],
                                )
                              ],
                            ),
                          ),
                        ),
                        const SizedBox(
                          height: 10,
                        ),
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 60),
                          child: Container(
                            height: 1,
                            color: Colors.black,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Image.asset(Assets.shared.imgProfile),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
