import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:tracking_app/services/firebase_operations.dart';
import 'package:tracking_app/views/welcome_screen.dart';

import '../../utils/assets.dart';
import 'custom_tab_bar.dart';
import 'haj_custom_tab_bar.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({Key? key}) : super(key: key);

  @override
  _SplashScreenState createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  var subscription;
  int state = 0;

  @override
  void initState() {
    super.initState();

    fetchReq();
  }

  @override
  void dispose() {
    // TODO: implement dispose
    super.dispose();
  }

  void fetchReq() async {
    // var delay = const Duration(seconds: 3);
    // Future.delayed(delay, () async {
    //   Get.offAll(() => WelcomeScreen());
    // });

    var delay = const Duration(seconds: 3);
    var user = getLocalUser();

    Future.delayed(delay, () async {
      if (user != null) {
        Get.offAll(
          () => const CustomTabBar(),
        );
      } else {
        var haj = getLocalHaj();

        if (haj != null) {
          Get.offAll(
            () => const HajCustomTabBar(),
          );
        } else {
          Get.offAll(() => const WelcomeScreen());
        }
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.white,
      child: Column(
        children: [
          const SizedBox(
            height: 150,
          ),
          Image.asset(
            Assets.shared.icLogo,
            width: 300.r,
            height: 300.r,
          ),
        ],
      ),
    );
  }
}
