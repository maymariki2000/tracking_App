import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:tracking_app/model/notifications_model.dart';
import 'package:tracking_app/views/add_user_data.dart';
import 'package:tracking_app/views/custom_tab_bar.dart';
import 'package:tracking_app/views/haj_map.dart';
import 'package:tracking_app/views/map_tracking_screen.dart';
import 'package:tracking_app/views/notification_screen.dart';
import 'package:tracking_app/views/register_screen.dart';
import 'package:tracking_app/views/success_screen.dart';

import '../custom_widgets/custom_app_bar.dart';
import '../custom_widgets/custom_text.dart';
import '../custom_widgets/custom_text_field.dart';
import '../custom_widgets/main_button.dart';
import '../model/haj_model.dart';
import '../services/firebase_operations.dart';
import '../utils/assets.dart';

class HajHomeScreen extends StatefulWidget {
  const HajHomeScreen({Key? key}) : super(key: key);

  @override
  State<HajHomeScreen> createState() => _HajHomeScreenState();
}

class _HajHomeScreenState extends State<HajHomeScreen> {
  HajModel? haj;

  void fetchHaj() async {
    HajModel? h = getLocalHaj();
    setState(() {
      haj = h;
    });
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    fetchHaj();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          "معلومات الحاج",
          style: TextStyle(color: Colors.black),
        ),
        automaticallyImplyLeading: false,
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(
            bottom: Radius.circular(30),
          ),
        ),
      ),
      body: SingleChildScrollView(
        // padding: EdgeInsets.all(20.r),
        child: SizedBox(
          width: double.infinity,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              SizedBox(
                height: 30.h,
              ),
              Container(
                padding: EdgeInsets.symmetric(horizontal: 20.w, vertical: 15.h),
                margin: EdgeInsets.symmetric(horizontal: 20.r),

                // height: 60.h,
                decoration: BoxDecoration(
                    color: Assets.shared.secondaryColor,
                    borderRadius: BorderRadius.circular(15),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.16),
                        offset: Offset(0, 3),
                        blurRadius: 6,
                      ),
                    ]),
                child: Row(
                  children: [
                    Image.asset(Assets.shared.imgProfile),
                    const SizedBox(
                      width: 10,
                    ),
                    Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        CustomText(
                          text: haj?.name ?? "",
                          fontSize: 20,
                          textColor: Assets.shared.primaryColor,
                        ),
                        const SizedBox(
                          height: 8,
                        ),
                        CustomText(
                          text: haj?.passport ?? "",
                          fontSize: 15,
                          textColor: Assets.shared.primaryColor,
                        ),
                        const SizedBox(
                          height: 15,
                        ),
                        Container(
                          height: 2,
                          width: 170.w,
                          decoration: BoxDecoration(
                              color: Assets.shared.primaryColor,
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.black.withOpacity(0.16),
                                  offset: const Offset(0, 3),
                                  blurRadius: 6,
                                ),
                              ]),
                        ),
                        const SizedBox(
                          height: 8,
                        ),
                        Row(
                          children: [
                            CustomText(
                              text: "تاريخ الميلاد",
                              fontSize: 14,
                              textColor: Assets.shared.primaryColor,
                            ),
                            const SizedBox(
                              width: 25,
                            ),
                            CustomText(
                              text: "رقم الحملة",
                              fontSize: 14,
                              textColor: Assets.shared.primaryColor,
                            ),
                          ],
                        ),
                        const SizedBox(
                          height: 8,
                        ),
                        Row(
                          children: [
                            CustomText(
                              text: haj?.birthdate ?? "",
                              fontSize: 14,
                              textColor: Assets.shared.primaryColor,
                            ),
                            const SizedBox(
                              width: 10,
                            ),
                            CustomText(
                              text: haj?.campaignNo ?? "",
                              fontSize: 14,
                              textColor: Assets.shared.primaryColor,
                            ),
                          ],
                        ),
                        const SizedBox(
                          height: 8,
                        ),
                        Row(
                          children: [
                            CustomText(
                              text: "الجنس",
                              fontSize: 14,
                              textColor: Assets.shared.primaryColor,
                            ),
                            const SizedBox(
                              width: 50,
                            ),
                            CustomText(
                              text: "فصيلة الدم",
                              fontSize: 14,
                              textColor: Assets.shared.primaryColor,
                            ),
                          ],
                        ),
                        const SizedBox(
                          height: 8,
                        ),
                        Row(
                          children: [
                            CustomText(
                              text: haj?.gender ?? "",
                              fontSize: 14,
                              textColor: Assets.shared.primaryColor,
                            ),
                            const SizedBox(
                              width: 70,
                            ),
                            CustomText(
                              text: haj?.bloodType ?? "",
                              fontSize: 14,
                              textColor: Assets.shared.primaryColor,
                            ),
                          ],
                        ),
                      ],
                    )
                  ],
                ),
              ),
              SizedBox(
                height: 20.h,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  Expanded(
                    child: Container(
                      height: 2,
                      // width: 170.w,
                      decoration: BoxDecoration(
                          color: Assets.shared.primaryColor,
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withOpacity(0.16),
                              offset: const Offset(0, 3),
                              blurRadius: 6,
                            ),
                          ]),
                    ),
                  ),
                  CustomText(
                    text: " الخدمات الالكترونية ",
                    fontSize: 20,
                    textColor: Assets.shared.primaryColor,
                  ),
                  Expanded(
                    child: Container(
                      height: 2,
                      // width: 170.w,
                      decoration: BoxDecoration(
                          color: Assets.shared.primaryColor,
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withOpacity(0.16),
                              offset: const Offset(0, 3),
                              blurRadius: 6,
                            ),
                          ]),
                    ),
                  ),
                ],
              ),
              SizedBox(
                height: 20.h,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    padding: EdgeInsets.all(5),
                    width: 100,
                    height: 150,
                    decoration: BoxDecoration(
                      color: Assets.shared.secondaryColor,
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Column(
                      children: [
                        InkWell(
                          onTap: () {
                            Get.to(() => const HajMapScreen());
                          },
                          child: Container(
                            width: 95,
                            height: 95,
                            decoration: BoxDecoration(
                              color: Assets.shared.primaryColor,
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: Image.asset(Assets.shared.icLoc),
                          ),
                        ),
                        const SizedBox(
                          height: 15,
                        ),
                        CustomText(
                          text: "تتبع",
                          fontSize: 16,
                          textColor: Assets.shared.primaryColor,
                        ),
                      ],
                    ),
                  ),
                  SizedBox(
                    width: 80.w,
                  ),
                  InkWell(
                    onTap: () {
                      showDialog(
                          context: context,
                          builder: (_) => AlertDialog(
                                shape: const RoundedRectangleBorder(
                                  borderRadius: BorderRadius.all(
                                    Radius.circular(12.0),
                                  ),
                                ),
                                content: Builder(
                                  builder: (context) {
                                    return SizedBox(
                                      height: 100,
                                      // width: width -
                                      //     10,
                                      child: Column(
                                        children: [
                                          const SizedBox(
                                            height: 8,
                                          ),
                                          const CustomText(
                                            text: "هل تريد ارسال طلب مساعدة؟",
                                            textColor: Colors.black,
                                            fontWeight: FontWeight.bold,
                                          ),
                                          const SizedBox(
                                            height: 15,
                                          ),
                                          MainButton(
                                            title: "ارسال",
                                            backgroundColor:
                                                Assets.shared.primaryColor,
                                            onPressed: () {
                                              var notf = NotificationModel(
                                                  title: "طلب مساعدة",
                                                  senderId: haj?.uid ?? "",
                                                  receiverId:
                                                      haj?.insertUid ?? "");
                                              saveNotificationToFire(notf);

                                              Navigator.pop(context);
                                              Get.to(
                                                () => const SuccessScreen(),
                                              );
                                              // setState(() {});
                                            },
                                          ),
                                        ],
                                      ),
                                    );
                                  },
                                ),
                              ));
                      // Get.defaultDialog(
                      //     title: "هل تريد ارسال طلب مساعدة؟",
                      //     middleText: "",
                      //     confirm: MainButton(
                      //         title: "ارسال",
                      //         backgroundColor: Assets.shared.primaryColor,
                      //         onPressed: () {
                      //           print("sss");
                      //           // var notf = NotificationModel(
                      //           //     title: "طلب مساعدة",
                      //           //     senderId: haj?.uid ?? "",
                      //           //     receiverId: haj?.insertUid ?? "");
                      //           // saveNotificationToFire(notf);
                      //           Get.back(closeOverlays: true);
                      //           // Get.to(
                      //           //   () => const SuccessScreen(),
                      //           // );
                      //         }),
                      //     onConfirm: () {});
                      // Get.to(
                      //   () => const SuccessScreen(),
                      // );
                    },
                    child: Container(
                      padding: EdgeInsets.all(5),
                      width: 100,
                      height: 150,
                      decoration: BoxDecoration(
                        color: Assets.shared.secondaryColor,
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Column(
                        children: [
                          Container(
                            width: 95,
                            height: 95,
                            decoration: BoxDecoration(
                              color: Assets.shared.primaryColor,
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: Image.asset(Assets.shared.icHelp),
                          ),
                          const SizedBox(
                            height: 12,
                          ),
                          CustomText(
                            text: "طلب مساعدة",
                            fontSize: 14,
                            textColor: Assets.shared.primaryColor,
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
