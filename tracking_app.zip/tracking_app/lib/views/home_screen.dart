import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:tracking_app/views/add_user_data.dart';
import 'package:tracking_app/views/custom_tab_bar.dart';
import 'package:tracking_app/views/edit_user_data.dart';
import 'package:tracking_app/views/list_haj_screen.dart';
import 'package:tracking_app/views/map_tracking_screen.dart';
import 'package:tracking_app/views/notification_screen.dart';
import 'package:tracking_app/views/register_screen.dart';

import '../custom_widgets/custom_app_bar.dart';
import '../custom_widgets/custom_text.dart';
import '../custom_widgets/custom_text_field.dart';
import '../custom_widgets/main_button.dart';
import '../model/company_model.dart';
import '../model/notifications_model.dart';
import '../model/user_model.dart';
import '../services/firebase_operations.dart';
import '../utils/assets.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  UserModel? _user;
  CompanyModel? company;
  List<NotificationModel> notifications = [];

  void fetchNotifications() async {
    UserModel? user = getLocalUser();
    List<NotificationModel> notf = await getNotifications(user?.uid ?? "");
    setState(() {
      notifications = notf.where((element) => element.isChecked == "").toList();
    });
  }

  void fetchUser() {
    UserModel? us = getLocalUser();
    _user = us;
    fetchCompany();
  }

  void fetchCompany() async {
    CompanyModel? co = await getCompanyByUid(_user?.companyId ?? "");
    setState(() {
      company = co;
    });
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    fetchUser();
    fetchNotifications();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          "معلومات المشرف",
          style: TextStyle(color: Colors.black),
        ),
        automaticallyImplyLeading: false,
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(
            bottom: Radius.circular(30),
          ),
        ),
      ),
      body: SingleChildScrollView(
        // padding: EdgeInsets.all(20.r),
        child: SizedBox(
          width: double.infinity,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              SizedBox(
                height: 30.h,
              ),
              // notifications.isNotEmpty
              //     ? Container(
              //         padding: EdgeInsets.symmetric(horizontal: 10.w),
              //         margin: EdgeInsets.symmetric(horizontal: 20.r),
              //         height: 60.h,
              //         decoration: BoxDecoration(
              //             color: Assets.shared.primaryColor,
              //             borderRadius: BorderRadius.circular(15),
              //             boxShadow: [
              //               BoxShadow(
              //                 color: Colors.black.withOpacity(0.16),
              //                 offset: Offset(0, 3),
              //                 blurRadius: 6,
              //               ),
              //             ]),
              //         child: Row(
              //           children: [
              //             Image.asset(Assets.shared.icNotification),
              //             const SizedBox(
              //               width: 10,
              //             ),
              //             Column(
              //               mainAxisAlignment: MainAxisAlignment.center,
              //               crossAxisAlignment: CrossAxisAlignment.start,
              //               children: const [
              //                 CustomText(
              //                   text: "تنبيهات",
              //                   textColor: Colors.white,
              //                 ),
              //                 SizedBox(
              //                   height: 5,
              //                 ),
              //                 CustomText(
              //                   text: "طلب مساعدة من حاج",
              //                   fontSize: 15,
              //                   textColor: Colors.white,
              //                 ),
              //               ],
              //             )
              //           ],
              //         ),
              //       )
              //     : SizedBox(),
              // SizedBox(
              //   height: notifications.isNotEmpty ? 15.h : 0,
              // ),
              Container(
                padding: EdgeInsets.symmetric(horizontal: 20.w, vertical: 15.h),
                margin: EdgeInsets.symmetric(horizontal: 20.r),

                // height: 60.h,
                decoration: BoxDecoration(
                    color: Assets.shared.secondaryColor,
                    borderRadius: BorderRadius.circular(15),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.16),
                        offset: Offset(0, 3),
                        blurRadius: 6,
                      ),
                    ]),
                child: Row(
                  children: [
                    Image.asset(Assets.shared.imgProfile),
                    const SizedBox(
                      width: 10,
                    ),
                    Expanded(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              CustomText(
                                text: _user?.name ?? "",
                                fontSize: 20,
                                textColor: Assets.shared.primaryColor,
                              ),
                            ],
                          ),
                          const SizedBox(
                            height: 8,
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              CustomText(
                                text: _user?.nationalId ?? "",
                                fontSize: 15,
                                textColor: Assets.shared.primaryColor,
                              ),
                            ],
                          ),
                          const SizedBox(
                            height: 20,
                          ),
                          Container(
                            height: 2,
                            width: 170.w,
                            decoration: BoxDecoration(
                                color: Assets.shared.primaryColor,
                                boxShadow: [
                                  BoxShadow(
                                    color: Colors.black.withOpacity(0.16),
                                    offset: const Offset(0, 3),
                                    blurRadius: 6,
                                  ),
                                ]),
                          ),
                          const SizedBox(
                            height: 15,
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              CustomText(
                                text: "شركة الطوافة",
                                fontSize: 14,
                                textColor: Assets.shared.primaryColor,
                              ),
                              // const SizedBox(
                              //   width: 25,
                              // ),
                              CustomText(
                                text: "رقم الحملة",
                                fontSize: 14,
                                textColor: Assets.shared.primaryColor,
                              ),
                            ],
                          ),
                          const SizedBox(
                            height: 15,
                          ),
                          Wrap(
                            // mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              CustomText(
                                text: company?.title ?? "",
                                fontSize: 14,
                                textColor: Assets.shared.primaryColor,
                              ),
                              // const SizedBox(
                              //   width: 10,
                              // ),
                              CustomText(
                                text: _user?.campaignNo ?? "",
                                fontSize: 14,
                                textColor: Assets.shared.primaryColor,
                              ),
                            ],
                          ),
                        ],
                      ),
                    )
                  ],
                ),
              ),
              SizedBox(
                height: 20.h,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  Expanded(
                    child: Container(
                      height: 2,
                      // width: 170.w,
                      decoration: BoxDecoration(
                          color: Assets.shared.primaryColor,
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withOpacity(0.16),
                              offset: const Offset(0, 3),
                              blurRadius: 6,
                            ),
                          ]),
                    ),
                  ),
                  CustomText(
                    text: " الخدمات الالكترونية ",
                    fontSize: 20,
                    textColor: Assets.shared.primaryColor,
                  ),
                  Expanded(
                    child: Container(
                      height: 2,
                      // width: 170.w,
                      decoration: BoxDecoration(
                          color: Assets.shared.primaryColor,
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withOpacity(0.16),
                              offset: const Offset(0, 3),
                              blurRadius: 6,
                            ),
                          ]),
                    ),
                  ),
                ],
              ),
              SizedBox(
                height: 20.h,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    padding: EdgeInsets.all(5),
                    width: 100,
                    height: 150,
                    decoration: BoxDecoration(
                      color: Assets.shared.secondaryColor,
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Column(
                      children: [
                        InkWell(
                          onTap: () {
                            Get.to(() => NotificationScreen());
                          },
                          child: Container(
                            width: 95,
                            height: 95,
                            decoration: BoxDecoration(
                              color: Assets.shared.primaryColor,
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: Image.asset(Assets.shared.icBell),
                          ),
                        ),
                        const SizedBox(
                          height: 15,
                        ),
                        CustomText(
                          text: "تنبيهات",
                          fontSize: 16,
                          textColor: Assets.shared.primaryColor,
                        ),
                      ],
                    ),
                  ),
                  SizedBox(
                    width: 80.w,
                  ),
                  InkWell(
                    onTap: () {
                      Get.to(
                        () => ListHajScreen(),
                      );
                    },
                    child: Container(
                      padding: EdgeInsets.all(5),
                      width: 100,
                      height: 150,
                      decoration: BoxDecoration(
                        color: Assets.shared.secondaryColor,
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Column(
                        children: [
                          Container(
                            width: 95,
                            height: 95,
                            decoration: BoxDecoration(
                              color: Assets.shared.primaryColor,
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: Image.asset(Assets.shared.icLoc),
                          ),
                          const SizedBox(
                            height: 15,
                          ),
                          CustomText(
                            text: "تتبع",
                            fontSize: 16,
                            textColor: Assets.shared.primaryColor,
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
              SizedBox(
                height: 15.h,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  InkWell(
                    onTap: () {
                      Get.to(() => AddUserDataScreen());
                    },
                    child: Container(
                      padding: EdgeInsets.all(5),
                      width: 100,
                      height: 160,
                      decoration: BoxDecoration(
                        color: Assets.shared.secondaryColor,
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Column(
                        children: [
                          Container(
                            width: 95,
                            height: 95,
                            decoration: BoxDecoration(
                              color: Assets.shared.primaryColor,
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: Image.asset(Assets.shared.icUserPlus),
                          ),
                          const SizedBox(
                            height: 8,
                          ),
                          CustomText(
                            text: "اضافة معلومات حاج",
                            fontSize: 14,
                            textColor: Assets.shared.primaryColor,
                          ),
                        ],
                      ),
                    ),
                  ),
                  SizedBox(
                    width: 80.w,
                  ),
                  InkWell(
                    onTap: () {
                      Get.to(
                        () => EditUserDataScreen(),
                      );
                    },
                    child: Container(
                      padding: EdgeInsets.all(5),
                      width: 100,
                      height: 160,
                      decoration: BoxDecoration(
                        color: Assets.shared.secondaryColor,
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Column(
                        children: [
                          Container(
                            width: 95,
                            height: 95,
                            decoration: BoxDecoration(
                              color: Assets.shared.primaryColor,
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: Image.asset(Assets.shared.icUserEdit),
                          ),
                          const SizedBox(
                            height: 8,
                          ),
                          CustomText(
                            text: "تعديل معلومات حاج",
                            fontSize: 14,
                            textColor: Assets.shared.primaryColor,
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
