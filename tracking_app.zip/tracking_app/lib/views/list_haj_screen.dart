import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:tracking_app/model/haj_model.dart';
import 'package:tracking_app/model/notifications_model.dart';
import 'package:tracking_app/model/user_model.dart';
import 'package:tracking_app/services/firebase_operations.dart';
import 'package:tracking_app/views/continue_add_user_data_screen.dart';

import '../custom_widgets/custom_app_bar.dart';
import '../custom_widgets/custom_text.dart';
import '../custom_widgets/custom_text_field.dart';
import '../custom_widgets/main_button.dart';
import '../utils/assets.dart';
import 'map_tracking_screen.dart';

class ListHajScreen extends StatefulWidget {
  ListHajScreen({Key? key}) : super(key: key);

  @override
  State<ListHajScreen> createState() => _ListHajScreenState();
}

class _ListHajScreenState extends State<ListHajScreen> {
  List<HajModel> hajs = [];

  void fetchHajs() async {
    UserModel? user = getLocalUser();
    List<HajModel> h = await getHajs(user?.uid ?? "");
    setState(() {
      hajs = h;
    });
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    fetchHajs();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CustomAppBar(
        title: "الحجاج",
      ),
      body: SizedBox(
        width: double.infinity,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Expanded(
              child: Container(
                decoration: BoxDecoration(
                  color: Assets.shared.primaryColor,
                  borderRadius: BorderRadius.circular(30),
                ),
                padding: EdgeInsets.symmetric(vertical: 20.h),
                margin: EdgeInsets.symmetric(horizontal: 14.w, vertical: 20.h),
                child: ListView.builder(
                  itemCount: hajs.length,
                  itemBuilder: (context, i) {
                    return InkWell(
                      onTap: () {
                        Get.to(
                          () => MapTrackingScreen(
                            haj: hajs[i],
                          ),
                        );
                      },
                      child: Container(
                        margin:
                            EdgeInsets.symmetric(vertical: 8, horizontal: 20),
                        padding: EdgeInsets.symmetric(horizontal: 12),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(30),
                        ),
                        height: 60,
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Image.asset(Assets.shared.icNot),
                            CustomText(
                              text: hajs[i].name ?? "",
                              fontSize: 16,
                              textColor: Assets.shared.primaryColor,
                            ),
                            Image.asset(Assets.shared.icCheck),
                          ],
                        ),
                      ),
                    );
                  },
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
