import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:tracking_app/utils/assets.dart';

import '../custom_widgets/custom_app_bar.dart';
import '../custom_widgets/custom_text.dart';
import '../custom_widgets/custom_text_field.dart';
import '../custom_widgets/main_button.dart';
import '../services/firebase_operations.dart';

class ForgotPasswordView extends StatelessWidget {
  ForgotPasswordView({Key? key}) : super(key: key);

  String email = "";

  Future<void> resetPassword({required String email}) async {
    if (email == "") {
      Fluttertoast.showToast(msg: "الرجاء ادخال البريد الالكتروني");
    } else {
      try {
        return await auth.sendPasswordResetEmail(email: email).then((value) {
          Fluttertoast.showToast(
              msg: "تم ارسال رابط اعادة تعيين كلمة المرور للبريد الالكتروني");
        });
      } catch (e) {
        print(e); // showError(title: '...', error: e);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CustomAppBar(
        title: "نسيت كلمة المرور",
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(20.r),
        child: SizedBox(
          width: double.infinity,
          child: Form(
            child: Column(
              children: [
                SizedBox(
                  height: 160.h,
                ),
                CustomTextField(
                  labelTitle: "ادخل بريدك الإلكتروني",
                  textInputType: TextInputType.emailAddress,
                  textInputAction: TextInputAction.done,
                  labelAlign: TextAlign.right,
                  labelAlignment: Alignment.centerRight,
                  textFiledColor: Assets.shared.secondaryColor,
                  onSaved: (String? value) {
                    email = value ?? "";
                  },
                  onSubmit: (val) {},
                ),
                SizedBox(
                  height: 120.h,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    ElevatedButton(
                      onPressed: () async {
                        resetPassword(email: email);
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Assets.shared.primaryColor,
                        padding: EdgeInsets.all(12.r),
                      ).copyWith(
                        shape:
                            MaterialStateProperty.all<RoundedRectangleBorder>(
                          RoundedRectangleBorder(
                            borderRadius:
                                BorderRadius.all(Radius.circular(20.r)),
                          ),
                        ),
                      ),
                      child: const CustomText(
                        text: "اعادة تعيين كلمة المرور",
                        textColor: Colors.white,
                        fontSize: 16,
                        fontWeight: FontWeight.normal,
                      ),
                    ),
                  ],
                ),
                SizedBox(
                  height: 20.h,
                ),
                CustomText(
                  text: "سيتم إرسال كلمة المرور الجديدة للبريد الإلكتروني",
                  textColor: Assets.shared.primaryColor,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
