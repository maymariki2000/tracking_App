import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:tracking_app/model/haj_model.dart';
import 'package:tracking_app/services/firebase_operations.dart';
import 'package:tracking_app/views/continue_add_user_data_screen.dart';

import '../custom_widgets/custom_app_bar.dart';
import '../custom_widgets/custom_text.dart';
import '../custom_widgets/custom_text_field.dart';
import '../custom_widgets/main_button.dart';
import '../utils/assets.dart';

class AddUserDataScreen extends StatefulWidget {
  AddUserDataScreen({Key? key}) : super(key: key);

  @override
  State<AddUserDataScreen> createState() => _AddUserDataScreenState();
}

class _AddUserDataScreenState extends State<AddUserDataScreen> {
  String name = "";

  String passport = "";

  String password = "";

  String birthdate = "";

  String gender = "";

  String campaignNo = "";

  String busNo = "";

  String nationality = "";

  String bloodType = "";

  List<String> genders = ["ذكر", "أنثى"];

  late HajModel haj;

  DateTime selectedDate = DateTime.now();

  TimeOfDay initialTime = TimeOfDay.now();

  TextEditingController dateController = TextEditingController();

  Future<void> _selectDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
        context: context,
        initialDate: selectedDate,
        locale: const Locale("en", "US"),
        firstDate: DateTime(1930, 1),
        lastDate: DateTime(2101));
    if (picked != null && picked != selectedDate) {
      setState(() {
        selectedDate = picked;
        dateController.text = "${selectedDate.toLocal()}".split(' ')[0];
        haj.birthdate = dateController.text;
      });
    }
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    haj = HajModel();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CustomAppBar(
        title: "اضافة معلومات الحاج",
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(20.r),
        child: SizedBox(
          width: double.infinity,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              SizedBox(
                height: 20.h,
              ),
              Container(
                decoration: BoxDecoration(
                  color: Assets.shared.primaryColor,
                  borderRadius: BorderRadius.circular(30),
                ),
                padding: EdgeInsets.symmetric(horizontal: 14.w, vertical: 20.h),
                child: Form(
                  child: Column(
                    children: [
                      CustomTextField(
                        labelTitle: "جواز السفر",
                        labelColor: Colors.white,
                        onSubmit: (val) async {
                          print(val);
                          HajModel? haj = await checkHajExists(val ?? "");
                          if (haj != null) {
                            Fluttertoast.showToast(
                                msg: "جواز  السفر مستخدم مسبقاً");
                          }
                        },
                        textAlign: TextAlign.right,
                        onSaved: (String? value) {
                          passport = value ?? "";
                          haj.passport = passport;
                        },
                      ),
                      SizedBox(
                        height: 16.h,
                      ),
                      CustomTextField(
                        labelTitle: "اسم المستخدم",
                        textInputAction: TextInputAction.next,
                        onSubmit: (val) {},
                        labelColor: Colors.white,
                        textAlign: TextAlign.right,
                        onSaved: (String? value) {
                          name = value ?? "";
                          haj.name = name;
                        },
                      ),
                      SizedBox(
                        height: 16.h,
                      ),
                      CustomTextField(
                        labelTitle: "كلمة المرور",
                        obscureText: true,
                        onSubmit: (val) {},
                        labelColor: Colors.white,
                        textAlign: TextAlign.right,
                        onSaved: (String? value) {
                          password = value ?? "";
                          haj.password = password;
                        },
                      ),
                      SizedBox(
                        height: 16.h,
                      ),
                      Column(
                        children: [
                          const CustomText(
                            text: "تاريخ الميلاد بالميلادي",
                            fontWeight: FontWeight.normal,
                            fontSize: 14,
                            textColor: Colors.white,
                            alignment: Alignment.centerRight,
                            textAlign: TextAlign.right,
                          ),
                          SizedBox(
                            height: 12.h,
                          ),
                          TextFormField(
                            controller: dateController,
                            textAlign: TextAlign.right,
                            readOnly: true,
                            onChanged: (val) {
                              haj.birthdate = val;
                            },
                            onTap: () {
                              _selectDate(context);
                            },
                            decoration: InputDecoration(
                              enabledBorder: OutlineInputBorder(
                                borderSide:
                                    BorderSide(width: 0, color: Colors.white),
                                borderRadius: BorderRadius.circular(25.0),
                              ),
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(25.0),
                              ),
                              filled: true,
                              fillColor: Colors.white,
                              hintText: "تاريخ الميلاد بالميلادي",
                            ),
                          ),
                        ],
                      ),
                      SizedBox(
                        height: 16.h,
                      ),
                      Stack(
                        clipBehavior: Clip.none,
                        alignment: Alignment.center,
                        children: [
                          TextFormField(
                            textAlign: TextAlign.right,
                            readOnly: true,
                            controller: gender == ""
                                ? null
                                : TextEditingController(text: gender),
                            decoration: InputDecoration(
                                suffixIcon:
                                    const Icon(Icons.keyboard_arrow_down),
                                enabledBorder: OutlineInputBorder(
                                  borderSide: const BorderSide(
                                      width: 0, color: Colors.white),
                                  borderRadius: BorderRadius.circular(25.0),
                                ),
                                border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(25.0),
                                ),
                                filled: true,
                                fillColor: Colors.white,
                                hintText: "الجنس"),
                          ),
                          Column(
                            children: [
                              const SizedBox(
                                height: 35,
                              ),
                              SizedBox(
                                width: double.infinity,
                                height: 50,
                                child: DropdownButton(
                                    icon: const SizedBox(),
                                    underline: const SizedBox(),
                                    items: genders.map((items) {
                                      return DropdownMenuItem<String>(
                                        value: items,
                                        child: Text(items),
                                      );
                                    }).toList(),
                                    onChanged: (val) {
                                      setState(() {
                                        var index = genders.indexOf(val!);
                                        gender = genders[index];
                                        haj.gender = gender;
                                      });
                                    }),
                              ),
                            ],
                          ),
                        ],
                      ),
                      SizedBox(
                        height: 16.h,
                      ),
                      CustomTextField(
                        labelTitle: "رقم الحملة",
                        labelColor: Colors.white,
                        onSubmit: (val) {},
                        textAlign: TextAlign.right,
                        onSaved: (String? value) {
                          campaignNo = value ?? "";
                          haj.campaignNo = campaignNo;
                        },
                      ),
                      SizedBox(
                        height: 25.h,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          MainButton(
                            title: "التالي",
                            onPressed: () {
                              if (haj.name == null ||
                                  haj.campaignNo == null ||
                                  haj.password == null ||
                                  haj.gender == null) {
                                Fluttertoast.showToast(
                                    msg: "الرجاء ملئ جميع الحقول");
                                return;
                              }
                              Get.to(() => ContinueAddUserDataScreen(
                                    haj: haj,
                                  ));
                            },
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}
