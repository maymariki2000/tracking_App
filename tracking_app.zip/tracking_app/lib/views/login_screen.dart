import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:tracking_app/views/custom_tab_bar.dart';
import 'package:tracking_app/views/register_screen.dart';

import '../custom_widgets/custom_app_bar.dart';
import '../custom_widgets/custom_text.dart';
import '../custom_widgets/custom_text_field.dart';
import '../custom_widgets/main_button.dart';
import '../model/status_response.dart';
import '../model/user_model.dart';
import '../services/firebase_constants.dart';
import '../services/firebase_operations.dart';
import '../utils/assets.dart';
import 'forgot_password_screen.dart';

class LoginScreen extends StatelessWidget {
  LoginScreen({Key? key}) : super(key: key);

  String email = "";
  String password = "";

  void performSignIn() async {
    if (email == "" || password == "") {
      Fluttertoast.showToast(msg: "الرجاء ملئ جميع الحقول");
    } else {
      StatusResponse response = await signInFireUser(email, password);
      if (response != null) {
        if (response.status) {
          final FirebaseAuth auth = FirebaseAuth.instance;
          final User? fireUser = auth.currentUser;
          final uid = fireUser!.uid;

          UserModel? user = await getCurrentUser(uid);
          if (user != null) {
            saveUserToLocal(user);
            print("user ${user.toString()}");
            Fluttertoast.showToast(msg: "تم تسجيل الدخول بنجاح");

            Get.offAll(
              () => const CustomTabBar(),
            );
          }
        } else {
          Fluttertoast.showToast(msg: response.message);
        }
      } else {
        Fluttertoast.showToast(msg: "عذراً بيانات الدخول خاطئة");
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CustomAppBar(
        title: "تسجيل الدخول",
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(20.r),
        child: SizedBox(
          width: double.infinity,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              SizedBox(
                height: 50.h,
              ),
              Container(
                margin: EdgeInsets.symmetric(horizontal: 50.w),
                height: 50,
                decoration: BoxDecoration(
                  color: Assets.shared.primaryColor,
                  borderRadius: BorderRadius.circular(25),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    TextButton(
                      onPressed: () {
                        Get.to(
                          () => RegisterScreen(),
                        );
                      },
                      child: const CustomText(
                        text: "انشاء حساب",
                        fontSize: 15,
                        textColor: Colors.white,
                      ),
                    ),
                    TextButton(
                      onPressed: () {},
                      child: Container(
                        padding: EdgeInsets.symmetric(horizontal: 10),
                        decoration: BoxDecoration(
                          color: Assets.shared.secondaryColor,
                          borderRadius: BorderRadius.circular(25),
                        ),
                        child: CustomText(
                          text: "تسجيل الدخول",
                          fontSize: 15,
                          textColor: Assets.shared.primaryColor,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              SizedBox(
                height: 16.h,
              ),
              Container(
                decoration: BoxDecoration(
                  color: Assets.shared.primaryColor,
                  borderRadius: BorderRadius.circular(30),
                ),
                padding: EdgeInsets.symmetric(horizontal: 14.w, vertical: 20.h),
                child: Form(
                  child: Column(
                    children: [
                      CustomTextField(
                        labelTitle: "أدخل البريد الالكتروني",
                        textInputAction: TextInputAction.next,
                        onSubmit: (val) {},
                        labelColor: Colors.white,
                        textAlign: TextAlign.right,
                        onSaved: (String? value) {
                          email = value ?? "";
                        },
                      ),
                      SizedBox(
                        height: 16.h,
                      ),
                      CustomTextField(
                        labelTitle: "ادخل كلمة المرور",
                        obscureText: true,
                        onSubmit: (val) {},
                        labelColor: Colors.white,
                        textAlign: TextAlign.right,
                        onSaved: (String? value) {
                          password = value ?? "";
                        },
                      ),
                      SizedBox(
                        height: 12.h,
                      ),
                      Row(
                        // mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          TextButton(
                            onPressed: () {
                              Get.to(() => ForgotPasswordView());
                            },
                            child: const CustomText(
                              text: "نسيت كلمة المرور ؟",
                              fontWeight: FontWeight.normal,
                              fontSize: 14,
                              textColor: Colors.white,
                            ),
                          ),
                        ],
                      ),
                      SizedBox(
                        height: 20.h,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          MainButton(
                            title: "تسجيل الدخول",
                            onPressed: () {
                              performSignIn();
                            },
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}
