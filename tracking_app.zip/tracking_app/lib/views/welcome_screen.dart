import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:tracking_app/custom_widgets/main_button.dart';
import 'package:tracking_app/views/haj_login_screen.dart';
import 'package:tracking_app/views/login_screen.dart';
import 'package:tracking_app/views/register_screen.dart';

import '../../utils/assets.dart';

class WelcomeScreen extends StatefulWidget {
  const WelcomeScreen({Key? key}) : super(key: key);

  @override
  _WelcomeScreenState createState() => _WelcomeScreenState();
}

class _WelcomeScreenState extends State<WelcomeScreen> {
  @override
  void initState() {
    super.initState();

    fetchReq();
  }

  @override
  void dispose() {
    // TODO: implement dispose
    super.dispose();
  }

  void fetchReq() async {
    var delay = const Duration(seconds: 3);
    Future.delayed(delay, () async {
      // Get.offAll(() => CustomTabBar());
    });
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.white,
      child: Column(
        children: [
          const SizedBox(
            height: 150,
          ),
          Image.asset(
            Assets.shared.icLogo,
            width: 300.r,
            height: 300.r,
          ),
          const SizedBox(
            height: 50,
          ),
          Container(
            height: 140,
            color: Assets.shared.primaryColor,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                SizedBox(
                  height: 60,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      MainButton(
                        title: "تسجيل الدخول",
                        fontSize: 14,
                        onPressed: () {
                          Get.to(() => LoginScreen());
                        },
                      ),
                      const SizedBox(
                        width: 10,
                      ),
                      MainButton(
                        title: "انشاء حساب جديد",
                        fontSize: 14,
                        onPressed: () {
                          Get.to(
                            () => RegisterScreen(),
                          );
                        },
                      ),
                    ],
                  ),
                ),
                const SizedBox(
                  height: 15,
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: MainButton(
                    title: "تسجيل دخول حاج",
                    fontSize: 14,
                    onPressed: () {
                      Get.to(() => HajLoginScreen());
                    },
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(
            height: 40,
          ),
          Image.asset(
            Assets.shared.imgStreet,
            fit: BoxFit.fill,
            // height: 75.h,
          ),
        ],
      ),
    );
  }
}
