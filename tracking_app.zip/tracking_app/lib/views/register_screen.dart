import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:tracking_app/model/company_model.dart';
import 'package:tracking_app/services/firebase_operations.dart';
import 'package:tracking_app/views/login_screen.dart';

import '../custom_widgets/custom_app_bar.dart';
import '../custom_widgets/custom_text.dart';
import '../custom_widgets/custom_text_field.dart';
import '../custom_widgets/main_button.dart';
import '../model/status_response.dart';
import '../utils/assets.dart';
import 'custom_tab_bar.dart';

class RegisterScreen extends StatefulWidget {
  RegisterScreen({Key? key}) : super(key: key);

  @override
  State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  String email = "";

  String name = "";

  String nationalId = "";

  String company = "";

  String campaignNumber = "";

  String password = "";

  CompanyModel? selectedCompany;

  List<CompanyModel> companies = [];

  void fetchCompanies() async {
    List<CompanyModel> types = await getCompanies();
    setState(() {
      companies = types;
    });
  }

  Future<void> performSignUp() async {
    if (email == "" ||
        name == "" ||
        password == "" ||
        nationalId == "" ||
        company == "" ||
        selectedCompany == null) {
      Fluttertoast.showToast(msg: "الرجاء ملئ جميع الحقول");
    } else {
      StatusResponse status = await createFireUser(name, email, nationalId,
          password, selectedCompany?.uid ?? "", campaignNumber);
      print(status);

      if (status != null) {
        Fluttertoast.showToast(msg: status.message);
        if (status.status) {
          Get.offAll(() => const CustomTabBar());
        }
      } else {}
    }
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    fetchCompanies();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CustomAppBar(
        title: "انشاء حساب جديد",
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(20.r),
        child: SizedBox(
          width: double.infinity,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              SizedBox(
                height: 20.h,
              ),
              Container(
                margin: EdgeInsets.symmetric(horizontal: 45.w),
                height: 50,
                decoration: BoxDecoration(
                  color: Assets.shared.primaryColor,
                  borderRadius: BorderRadius.circular(25),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    TextButton(
                      onPressed: () {},
                      child: Container(
                        padding: EdgeInsets.symmetric(horizontal: 10),
                        decoration: BoxDecoration(
                          color: Assets.shared.secondaryColor,
                          borderRadius: BorderRadius.circular(25),
                        ),
                        child: CustomText(
                          text: "انشاء حساب جديد",
                          fontSize: 15,
                          textColor: Assets.shared.primaryColor,
                        ),
                      ),
                    ),
                    TextButton(
                      onPressed: () {
                        Get.to(
                          () => LoginScreen(),
                        );
                      },
                      child: const CustomText(
                        text: "تسجيل الدخول",
                        fontSize: 15,
                        textColor: Colors.white,
                      ),
                    ),
                  ],
                ),
              ),
              SizedBox(
                height: 16.h,
              ),
              Container(
                decoration: BoxDecoration(
                  color: Assets.shared.primaryColor,
                  borderRadius: BorderRadius.circular(30),
                ),
                padding: EdgeInsets.symmetric(horizontal: 14.w, vertical: 20.h),
                child: Form(
                  child: Column(
                    children: [
                      CustomTextField(
                        labelTitle: "اسم المستخدم",
                        textInputAction: TextInputAction.next,
                        onSubmit: (val) {},
                        labelColor: Colors.white,
                        textAlign: TextAlign.right,
                        onSaved: (String? value) {
                          name = value ?? "";
                        },
                      ),
                      SizedBox(
                        height: 16.h,
                      ),
                      CustomTextField(
                        labelTitle: "البريد الالكتروني",
                        labelColor: Colors.white,
                        textAlign: TextAlign.right,
                        onSubmit: (val) {},
                        onSaved: (String? value) {
                          email = value ?? "";
                        },
                      ),
                      SizedBox(
                        height: 16.h,
                      ),
                      CustomTextField(
                        labelTitle: "الهوية الوطنية",
                        labelColor: Colors.white,
                        textAlign: TextAlign.right,
                        onSubmit: (val) {},
                        onSaved: (String? value) {
                          nationalId = value ?? "";
                        },
                      ),
                      SizedBox(
                        height: 16.h,
                      ),
                      CustomTextField(
                        labelTitle: "كلمة المرور",
                        obscureText: true,
                        labelColor: Colors.white,
                        onSubmit: (val) {},
                        textAlign: TextAlign.right,
                        onSaved: (String? value) {
                          password = value ?? "";
                        },
                      ),
                      SizedBox(
                        height: 16.h,
                      ),
                      Column(
                        children: [
                          const CustomText(
                            text: "شركة الطوافة",
                            fontWeight: FontWeight.normal,
                            fontSize: 14,
                            textColor: Colors.white,
                            alignment: Alignment.centerRight,
                            textAlign: TextAlign.right,
                          ),
                          SizedBox(
                            height: 12.h,
                          ),
                          Stack(
                            clipBehavior: Clip.none,
                            alignment: Alignment.center,
                            children: [
                              TextFormField(
                                textAlign: TextAlign.right,
                                readOnly: true,
                                controller: company == ""
                                    ? null
                                    : TextEditingController(text: company),
                                decoration: InputDecoration(
                                    suffixIcon:
                                        const Icon(Icons.keyboard_arrow_down),
                                    enabledBorder: OutlineInputBorder(
                                      borderSide: const BorderSide(
                                          width: 0, color: Colors.white),
                                      borderRadius: BorderRadius.circular(25.0),
                                    ),
                                    border: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(25.0),
                                    ),
                                    filled: true,
                                    fillColor: Colors.white,
                                    hintText: "شركة الطوافة"),
                              ),
                              Column(
                                children: [
                                  const SizedBox(
                                    height: 35,
                                  ),
                                  SizedBox(
                                    width: double.infinity,
                                    height: 50,
                                    child: DropdownButton(
                                        icon: const SizedBox(),
                                        underline: const SizedBox(),
                                        items: companies.map((items) {
                                          return DropdownMenuItem<CompanyModel>(
                                            value: items,
                                            child: Text(items.title),
                                          );
                                        }).toList(),
                                        onChanged: (val) {
                                          setState(() {
                                            var index = companies.indexOf(val!);
                                            selectedCompany = companies[index];
                                            company = companies[index].title;
                                          });
                                        }),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ],
                      ),
                      SizedBox(
                        height: 16.h,
                      ),
                      CustomTextField(
                        labelTitle: "رقم الحملة التابعة",
                        obscureText: true,
                        labelColor: Colors.white,
                        textAlign: TextAlign.right,
                        onSubmit: (val) {},
                        onSaved: (String? value) {
                          campaignNumber = value ?? "";
                        },
                      ),
                      SizedBox(
                        height: 25.h,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          MainButton(
                            title: "التسجيل",
                            onPressed: () {
                              performSignUp();
                            },
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}
