import 'dart:async';

import 'package:custom_info_window/custom_info_window.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:geocoding/geocoding.dart';
import 'package:tracking_app/custom_widgets/custom_app_bar.dart';
import 'package:tracking_app/custom_widgets/custom_text.dart';
import 'package:tracking_app/custom_widgets/main_button.dart';
import 'package:tracking_app/utils/assets.dart';

class SuccessScreen extends StatefulWidget {
  const SuccessScreen({Key? key}) : super(key: key);

  @override
  _SuccessScreenState createState() => _SuccessScreenState();
}

class _SuccessScreenState extends State<SuccessScreen> {
  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CustomAppBar(
        title: "طلب مساعدة",
      ),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          CustomText(
            text: "تم ارسال طلبك بنجاح",
            fontSize: 40,
            textColor: Assets.shared.primaryColor,
          ),
          const SizedBox(
            height: 40,
          ),
          Image.asset(Assets.shared.icSuccess),
        ],
      ),
    );
  }
}
