import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:tracking_app/model/haj_model.dart';

import '../custom_widgets/custom_app_bar.dart';
import '../custom_widgets/custom_text.dart';
import '../custom_widgets/custom_text_field.dart';
import '../custom_widgets/main_button.dart';
import '../model/company_model.dart';
import '../services/firebase_operations.dart';
import '../utils/assets.dart';

class ContinueAddUserDataScreen extends StatefulWidget {
  HajModel haj;
  ContinueAddUserDataScreen({Key? key, required this.haj}) : super(key: key);

  @override
  State<ContinueAddUserDataScreen> createState() =>
      _ContinueAddUserDataScreenState();
}

class _ContinueAddUserDataScreenState extends State<ContinueAddUserDataScreen> {
  String email = "";

  String nationality = "";

  CompanyModel? selectedNationality;

  List<CompanyModel> nationalities = [];

  void fetchCompanies() async {
    List<CompanyModel> types = await getNationalities();
    setState(() {
      nationalities = types;
    });
  }

  Future<void> performAddHaj() async {
    saveHajToFire(widget.haj);
    Fluttertoast.showToast(msg: "تم الحفظ بنجاح");
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    fetchCompanies();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CustomAppBar(
        title: "اضافة معلومات الحاج",
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(20.r),
        child: SizedBox(
          width: double.infinity,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              SizedBox(
                height: 20.h,
              ),
              Container(
                decoration: BoxDecoration(
                  color: Assets.shared.primaryColor,
                  borderRadius: BorderRadius.circular(30),
                ),
                padding: EdgeInsets.symmetric(horizontal: 14.w, vertical: 20.h),
                child: Form(
                  child: Column(
                    children: [
                      CustomTextField(
                        labelTitle: "رقم الباص المخصص",
                        textInputAction: TextInputAction.next,
                        onSubmit: (val) {},
                        labelColor: Colors.white,
                        textAlign: TextAlign.right,
                        onSaved: (String? value) {
                          widget.haj.busNo = value ?? "";
                        },
                      ),
                      SizedBox(
                        height: 16.h,
                      ),
                      Stack(
                        clipBehavior: Clip.none,
                        alignment: Alignment.center,
                        children: [
                          TextFormField(
                            textAlign: TextAlign.right,
                            readOnly: true,
                            controller: nationality == ""
                                ? null
                                : TextEditingController(text: nationality),
                            decoration: InputDecoration(
                                suffixIcon:
                                    const Icon(Icons.keyboard_arrow_down),
                                enabledBorder: OutlineInputBorder(
                                  borderSide: const BorderSide(
                                      width: 0, color: Colors.white),
                                  borderRadius: BorderRadius.circular(25.0),
                                ),
                                border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(25.0),
                                ),
                                filled: true,
                                fillColor: Colors.white,
                                hintText: "الجنسية"),
                          ),
                          Column(
                            children: [
                              const SizedBox(
                                height: 35,
                              ),
                              SizedBox(
                                width: double.infinity,
                                height: 50,
                                child: DropdownButton(
                                    icon: const SizedBox(),
                                    underline: const SizedBox(),
                                    items: nationalities.map((items) {
                                      return DropdownMenuItem<CompanyModel>(
                                        value: items,
                                        child: Text(items.title),
                                      );
                                    }).toList(),
                                    onChanged: (val) {
                                      setState(() {
                                        var index = nationalities.indexOf(val!);
                                        selectedNationality =
                                            nationalities[index];
                                        nationality =
                                            nationalities[index].title;
                                        widget.haj.nationality =
                                            nationalities[index].uid;
                                      });
                                    }),
                              ),
                            ],
                          ),
                        ],
                      ),
                      SizedBox(
                        height: 16.h,
                      ),
                      Column(
                        children: [
                          // const CustomText(
                          //   text: "فصيلة دم الحاج",
                          //   fontWeight: FontWeight.normal,
                          //   fontSize: 14,
                          //   textColor: Colors.white,
                          //   alignment: Alignment.centerRight,
                          //   textAlign: TextAlign.right,
                          // ),
                          // SizedBox(
                          //   height: 12.h,
                          // ),
                          CustomTextField(
                            labelTitle: "فصيلة دم الحاج",
                            textInputAction: TextInputAction.next,
                            onSubmit: (val) {},
                            labelColor: Colors.white,
                            textAlign: TextAlign.right,
                            onSaved: (String? value) {
                              widget.haj.bloodType = value ?? "";
                            },
                          ),
                        ],
                      ),
                      SizedBox(
                        height: 25.h,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          MainButton(
                            title: "إضافة",
                            onPressed: () {
                              if (widget.haj.bloodType == null ||
                                  widget.haj.busNo == null ||
                                  widget.haj.nationality == null) {
                                Fluttertoast.showToast(
                                    msg: "الرجاء ملئ جميع الحقول");
                                return;
                              }
                              performAddHaj();
                            },
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}
