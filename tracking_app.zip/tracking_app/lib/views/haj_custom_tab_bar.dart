import 'package:flutter/material.dart';
import 'package:tracking_app/views/haj_profile.dart';
import 'package:tracking_app/views/home_screen.dart';
import 'package:tracking_app/views/profile_screen.dart';
import 'package:tracking_app/views/welcome_screen.dart';

import '../utils/assets.dart';
import 'haj_home_screen.dart';

class HajCustomTabBar extends StatefulWidget {
  const HajCustomTabBar({super.key});

  @override
  _HajCustomTabBarState createState() => _HajCustomTabBarState();
}

class _HajCustomTabBarState extends State<HajCustomTabBar>
    with TickerProviderStateMixin {
  final PageStorageBucket bucket = PageStorageBucket();
  late TabController tabController;
  // late bool isSignIn;

  @override
  void initState() {
    super.initState();
    tabController = TabController(length: 2, vsync: this);
    tabController.addListener(_handleTabSelection);
    checkSignIn();
  }

  void _handleTabSelection() {
    print(tabController.index);

    setState(() {});
  }

  int _currentIndex = 0;
  final List<Widget> _children = [
    const HajProfileScreen(),
    const HajHomeScreen(),
    // const HajHomeScreen(),
    // const HajProfileScreen(),
  ];

  Future<void> checkSignIn() async {
    // bool isSignedIn = await checkUserSignIn();
    // this.isSignIn = isSignedIn;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: PageStorage(
        bucket: bucket,
        child: TabBarView(
          controller: tabController,
          physics: const NeverScrollableScrollPhysics(),
          children: _children,
        ),
      ),

      bottomNavigationBar: Material(
        color: Colors.white,
        elevation: 0,
        child: BottomAppBar(
          color: Assets.shared.secondaryColor,
          child: TabBar(
            physics: NeverScrollableScrollPhysics(),
            controller: tabController,
            tabs: [
              Tab(
                icon: Image.asset(
                  Assets.shared.icProfile,
                  width: 35,
                  height: 35,
                  color: Colors.black,
                ),
                text: "الصفحة الشخصية",
              ),
              Tab(
                icon: Image.asset(
                  Assets.shared.icHome,
                  width: 35,
                  height: 35,
                  color: Colors.black,
                ),
                text: "الصفحة الرئيسية",
              ),
              // Tab(
              //   icon: Image.asset(
              //     Assets.shared.icLogout,
              //     width: 35,
              //     height: 35,
              //     color: Colors.black,
              //   ),
              //   text: "تسجيل الخروج",
              // ),
            ],
            isScrollable: false,
            labelColor: Colors.black,
            indicatorSize: TabBarIndicatorSize.tab,
            indicatorColor: Colors.transparent,
          ),
        ),
      ),

      // bottomNavigationBar: BottomAppBarItems(
      //   index: 2,
      // ),
    );
  }

  void onTabTapped(int index) {
    setState(() {
      _currentIndex = index;
    });
  }
}
