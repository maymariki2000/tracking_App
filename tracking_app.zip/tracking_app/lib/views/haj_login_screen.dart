import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:tracking_app/views/custom_tab_bar.dart';
import 'package:tracking_app/views/haj_custom_tab_bar.dart';
import 'package:tracking_app/views/register_screen.dart';

import '../custom_widgets/custom_app_bar.dart';
import '../custom_widgets/custom_text.dart';
import '../custom_widgets/custom_text_field.dart';
import '../custom_widgets/main_button.dart';
import '../model/haj_model.dart';
import '../model/status_response.dart';
import '../model/user_model.dart';
import '../services/firebase_constants.dart';
import '../services/firebase_operations.dart';
import '../utils/assets.dart';

class HajLoginScreen extends StatelessWidget {
  HajLoginScreen({Key? key}) : super(key: key);

  String passport = "";
  String password = "";

  void performLogin() async {
    HajModel? hajData = await checkHajExists(passport);

    if (hajData != null) {
      if (hajData.password == password) {
        print("logged in");
        saveHajToLocal(hajData);
        Get.offAll(
          () => const HajCustomTabBar(),
        );
      } else {
        Fluttertoast.showToast(msg: "الرجاء التاكد من البيانات المدخلة");
      }
    } else {
      Fluttertoast.showToast(msg: "الرجاء التاكد من البيانات المدخلة");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CustomAppBar(
        title: "تسجيل دخول الحاج",
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(20.r),
        child: SizedBox(
          width: double.infinity,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              SizedBox(
                height: 50.h,
              ),
              Container(
                decoration: BoxDecoration(
                  color: Assets.shared.primaryColor,
                  borderRadius: BorderRadius.circular(30),
                ),
                padding: EdgeInsets.symmetric(horizontal: 14.w, vertical: 20.h),
                child: Form(
                  child: Column(
                    children: [
                      CustomTextField(
                        labelTitle: "أدخل رقم جواز السفر",
                        textInputAction: TextInputAction.next,
                        textInputType: TextInputType.number,
                        onSubmit: (val) {},
                        labelColor: Colors.white,
                        textAlign: TextAlign.right,
                        onSaved: (String? value) {
                          passport = value ?? "";
                        },
                      ),
                      SizedBox(
                        height: 16.h,
                      ),
                      CustomTextField(
                        labelTitle: "ادخل كلمة المرور",
                        obscureText: true,
                        onSubmit: (val) {},
                        labelColor: Colors.white,
                        textAlign: TextAlign.right,
                        onSaved: (String? value) {
                          password = value ?? "";
                        },
                      ),
                      SizedBox(
                        height: 20.h,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          MainButton(
                            title: "تسجيل الدخول",
                            onPressed: () {
                              performLogin();
                            },
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}
