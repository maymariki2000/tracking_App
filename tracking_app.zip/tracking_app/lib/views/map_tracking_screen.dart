import 'dart:async';

import 'package:custom_info_window/custom_info_window.dart';
import 'package:dio/dio.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_polyline_points/flutter_polyline_points.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:geocoding/geocoding.dart';
import 'package:tracking_app/custom_widgets/custom_text.dart';
import 'package:tracking_app/custom_widgets/custom_text_field.dart';
import 'package:tracking_app/custom_widgets/main_button.dart';
import 'package:tracking_app/model/haj_model.dart';
import 'package:tracking_app/utils/assets.dart';
import 'package:location/location.dart' as Loc;

import '../custom_widgets/custom_app_bar.dart';
import '../model/notifications_model.dart';
import '../services/firebase_operations.dart';

class MapTrackingScreen extends StatefulWidget {
  HajModel haj;
  MapTrackingScreen({Key? key, required this.haj}) : super(key: key);

  @override
  _MapTrackingScreenState createState() => _MapTrackingScreenState();
}

class _MapTrackingScreenState extends State<MapTrackingScreen> {
  final Completer<GoogleMapController> _controller =
      Completer<GoogleMapController>();

  CustomInfoWindowController _customInfoWindowController =
      CustomInfoWindowController();

  static const CameraPosition _kGooglePlex = CameraPosition(
    target: LatLng(21.422510, 39.826168),
    zoom: 12,
  );

  List<dynamic> markersList = [];
  Map<MarkerId, Marker> markers = {};

  Loc.Location location = Loc.Location();

  bool? _serviceEnabled;
  Loc.PermissionStatus? _permissionGranted;
  Loc.LocationData? _locationData;
  String currentPoint = "";
  String googleAPiKey = "AIzaSyC1xTzuJMYp8F4Vs9dxiJZg3iAJkaEwipM";
  Map<PolylineId, Polyline> polylines = {};

  String startPoint = "19.1113716-41.9206472";
  String endPoint = "19.1096611-41.9194976";

  _addMarker(LatLng position, String id) {
    MarkerId markerId = MarkerId(id);
    Marker marker =
        Marker(markerId: markerId, position: position, onTap: () async {});
    markers[markerId] = marker;
  }

  void getCurrentLocation() async {
    print("ffff");
    _serviceEnabled = await location.serviceEnabled();
    if (!(_serviceEnabled ?? false)) {
      _serviceEnabled = await location.requestService();
      if (!(_serviceEnabled ?? false)) {
        return;
      }
    }

    _permissionGranted = await location.hasPermission();

    if (_permissionGranted == Loc.PermissionStatus.denied) {
      _permissionGranted = await location.requestPermission();
      if (_permissionGranted != Loc.PermissionStatus.granted) {
        return;
      }
    }

    _locationData = await location.getLocation();

    location.onLocationChanged.listen((Loc.LocationData loc) {
      if (currentPoint == "") {
        currentPoint = "${loc.latitude}-${loc.longitude}";

        setSourceAndDestinationIcons();
      }

      // setState(() {});
    });
  }

  @override
  void dispose() {
    // TODO: implement dispose
    super.dispose();
  }

  void setSourceAndDestinationIcons() async {
    var vv = widget.haj.latLng?.split("-");
    var currentUser = currentPoint.split("-");

    if (vv != null) {
      print("vv is $vv");
      _addMarker(
          LatLng(double.parse(vv[0]), double.parse(vv[1])), "${vv[0]}_origin");
    }

    if (currentUser != null) {
      _addMarker(
        LatLng(double.parse(currentUser[0]), double.parse(currentUser[1])),
        (currentUser[0]) + "_destination",
      );
    }

    List<LatLng> polylineCoordinates = [];

    polylineCoordinates.add(LatLng(double.parse(vv![0]), double.parse(vv[1])));
    polylineCoordinates.add(
        LatLng(double.parse(currentUser[0]), double.parse(currentUser[1])));

    _getPolyline(
        double.parse(vv[0]),
        double.parse(vv[1]),
        double.parse(currentUser[0]),
        double.parse(currentUser[1]),
        widget.haj.uid ?? "",
        polylineCoordinates);
  }

  _getPolyline(double originLat, double originLng, double desLat, double desLng,
      String uid, List<LatLng> polylineCoordinates) async {
    PolylinePoints polylinePoints = PolylinePoints();
    // PolylineResult result = await polylinePoints.getRouteBetweenCoordinates(googleAPiKey,
    //     _originLatitude, _originLongitude, _destLatitude, _destLongitude);

    getDistanceTime(originLat, originLng, desLat, desLng);
    PolylineResult result = await polylinePoints.getRouteBetweenCoordinates(
      googleAPiKey,
      PointLatLng(originLat, originLng),
      PointLatLng(desLat, desLng),
      travelMode: TravelMode.driving,
    );
    print("result.points = ${result.points}");
    if (result.points.isNotEmpty) {
      result.points.forEach((PointLatLng point) {
        print("dddddsds");
        polylineCoordinates.add(LatLng(point.latitude, point.longitude));
      });
    }

    _addPolyLine(uid, polylineCoordinates);
  }

  _addPolyLine(String uid, List<LatLng> polylineCoordinates) {
    PolylineId id = const PolylineId("poly");
    Polyline polyline = Polyline(
        polylineId: id, color: Colors.red, points: polylineCoordinates);
    polylines[id] = polyline;
    print("polyline = $polyline");
    if (this.mounted) {
      print("Mmounted");
      setState(() {
        // Your state change code goes here
      });
    }
    // setState(() {});
  }

  void getDistanceTime(
      double lat1, double lng1, double lat2, double lng2) async {
    Dio dio = Dio();
    Response response = await dio.get(
        "https://maps.googleapis.com/maps/api/distancematrix/json?units=imperial&origins=$lat1,$lng1&destinations=$lat2,$lng2&key=$googleAPiKey");
    print("dddddd ===============");
    print(response.data);
  }

  @override
  void initState() {
    super.initState();
    getCurrentLocation();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CustomAppBar(
        title: "تتبع الحاج",
      ),
      body: Stack(
        children: [
          GoogleMap(
            mapType: MapType.normal,
            initialCameraPosition: _kGooglePlex,
            markers: Set<Marker>.of(markers.values),
            onTap: (position) {
              // getLocationData(position);
            },
            polylines: Set<Polyline>.of(polylines.values),
            onMapCreated: (GoogleMapController controller) {
              _controller.complete(controller);
              _customInfoWindowController.googleMapController = controller;
            },
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const Expanded(
                child: SizedBox(),
              ),
              Container(
                margin: EdgeInsets.symmetric(horizontal: 15.w),
                padding: EdgeInsets.symmetric(horizontal: 15.w),
                height: 150,
                decoration: BoxDecoration(
                  color: Assets.shared.primaryColor,
                  borderRadius: BorderRadius.circular(25),
                ),
                child: Row(
                  children: [
                    Image.asset(Assets.shared.imgProfile),
                    SizedBox(
                      width: 5.w,
                    ),
                    Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        CustomText(
                          text: widget.haj.name ?? "",
                          textColor: Colors.white,
                          fontSize: 20,
                        ),
                        const SizedBox(
                          height: 5,
                        ),
                        CustomText(
                          text: widget.haj.passport ?? "",
                          textColor: Colors.white,
                          fontSize: 15,
                        ),
                        const SizedBox(
                          height: 5,
                        ),
                        // const CustomText(
                        //   text: "يعد عنك ٢٠ دقيقة",
                        //   textColor: Colors.white,
                        //   fontSize: 15,
                        // ),
                      ],
                    ),
                    const SizedBox(
                      width: 10,
                    ),
                    Column(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        MainButton(
                            title: "تنبيه الحاج",
                            onPressed: () {
                              var txt = "تنبيه";
                              var notf = NotificationModel(
                                  title: txt,
                                  senderId: widget.haj.insertUid ?? "",
                                  receiverId: widget.haj.uid ?? "");
                              saveNotificationToFire(notf);

                              Fluttertoast.showToast(msg: "تم الارسال بنجاح");

                              // showDialog(
                              //     context: context,
                              //     builder: (_) => AlertDialog(
                              //           shape: const RoundedRectangleBorder(
                              //             borderRadius: BorderRadius.all(
                              //               Radius.circular(12.0),
                              //             ),
                              //           ),
                              //           content: Builder(
                              //             builder: (context) {
                              //               return SizedBox(
                              //                 height: 200,
                              //                 // width: width -
                              //                 //     10,
                              //                 child: Column(
                              //                   children: [
                              //                     const SizedBox(
                              //                       height: 8,
                              //                     ),
                              //                     const CustomText(
                              //                       text:
                              //                           "هل تريد تنبيه الحاج؟",
                              //                       textColor: Colors.black,
                              //                       fontWeight: FontWeight.bold,
                              //                     ),
                              //                     const SizedBox(
                              //                       height: 15,
                              //                     ),
                              //                     TextFormField(
                              //                       textAlign: TextAlign.right,
                              //                       onChanged: (value) {
                              //                         txt = value;
                              //                       },
                              //                       decoration: InputDecoration(
                              //                           enabledBorder:
                              //                               OutlineInputBorder(
                              //                             borderSide:
                              //                                 BorderSide(
                              //                                     width: 0,
                              //                                     color: Colors
                              //                                         .white),
                              //                             borderRadius:
                              //                                 BorderRadius
                              //                                     .circular(
                              //                                         25.0),
                              //                           ),
                              //                           border:
                              //                               OutlineInputBorder(
                              //                             borderRadius:
                              //                                 BorderRadius
                              //                                     .circular(
                              //                                         25.0),
                              //                           ),
                              //                           filled: true,
                              //                           fillColor: Assets.shared
                              //                               .secondaryColor,
                              //                           hintText:
                              //                               "اكتب الرسالة هنا"),
                              //                     ),
                              //                     const SizedBox(
                              //                       height: 15,
                              //                     ),
                              //                     MainButton(
                              //                       title: "ارسال",
                              //                       backgroundColor: Assets
                              //                           .shared.primaryColor,
                              //                       onPressed: () {
                              //                         var notf = NotificationModel(
                              //                             title: txt,
                              //                             senderId: widget.haj
                              //                                     .insertUid ??
                              //                                 "",
                              //                             receiverId:
                              //                                 widget.haj.uid ??
                              //                                     "");
                              //                         saveNotificationToFire(
                              //                             notf);
                              //
                              //                         Navigator.pop(context);
                              //                         Fluttertoast.showToast(
                              //                             msg:
                              //                                 "تم الارسال بنجاح");
                              //
                              //                         // setState(() {});
                              //                       },
                              //                     ),
                              //                   ],
                              //                 ),
                              //               );
                              //             },
                              //           ),
                              //         ));
                            }),
                        const SizedBox(
                          height: 10,
                        ),
                      ],
                    )
                  ],
                ),
              ),
              const SizedBox(
                height: 35,
              )
            ],
          )
          // CustomInfoWindow(
          //   controller: _customInfoWindowController,
          //   height: 50,
          //   width: 250.w,
          //   offset: 50,
          // ),
        ],
      ),
    );
  }
}
