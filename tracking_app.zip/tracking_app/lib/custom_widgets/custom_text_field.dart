import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../../utils/assets.dart';
import 'custom_text.dart';

class CustomTextField extends StatelessWidget {
  const CustomTextField({
    Key? key,
    required this.labelTitle,
    this.initialValue,
    this.obscureText,
    this.textInputType = TextInputType.text,
    this.textInputAction = TextInputAction.done,
    this.textAlign,
    this.labelAlign,
    this.labelAlignment,
    this.labelColor,
    this.textFiledColor,
    required this.onSaved,
    required this.onSubmit,
  }) : super(key: key);

  final String labelTitle;
  final String? initialValue;
  final bool? obscureText;
  final TextInputType textInputType;
  final TextInputAction textInputAction;
  final Function(String?) onSaved;
  final Function(String?) onSubmit;
  final TextAlign? textAlign;
  final TextAlign? labelAlign;
  final Alignment? labelAlignment;
  final Color? labelColor;
  final Color? textFiledColor;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        CustomText(
          text: labelTitle,
          fontWeight: FontWeight.normal,
          fontSize: 14,
          textColor: labelColor ?? Assets.shared.primaryColor,
          alignment: labelAlignment ?? Alignment.centerRight,
          textAlign: labelAlign ?? TextAlign.right,
        ),
        SizedBox(
          height: 12.h,
        ),
        TextFormField(
          controller: initialValue == null
              ? null
              : TextEditingController(text: initialValue),
          obscureText: obscureText ?? false,
          textAlign: textAlign ?? TextAlign.center,
          textInputAction: textInputAction,
          keyboardType: textInputType,
          onChanged: (value) => onSaved(value),
          onFieldSubmitted: (value) => onSubmit(value),
          decoration: InputDecoration(
              enabledBorder: OutlineInputBorder(
                borderSide: BorderSide(width: 0, color: Colors.white),
                borderRadius: BorderRadius.circular(25.0),
              ),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(25.0),
              ),
              filled: true,
              fillColor: textFiledColor ?? Colors.white,
              hintText: labelTitle),
        ),
      ],
    );
  }
}
